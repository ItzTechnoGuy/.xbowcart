package com.xbowcart.addon.modules;

import meteordevelopment.meteorclient.utils.player.InvUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * One inventory visit, driven frame by frame: open the inventory screen, do the swaps (the same
 * hotbar-number / offhand swap you get by hovering an item and pressing 1-9 or F), close the screen.
 *
 * Step mode: wait, swap, wait for the server's answer, check (redo only swaps the server undid), close.
 * Total mode: the whole visit lasts exactly the total time (25% before the first swap, the swaps
 * spread over the next 50%, close at the end) and nothing waits for the server; whether the swaps
 * worked is checked later by the caller.
 */
public class InvSession {
    /** Swap the slot {@code hotbar} (hotbar 0-8, leggings 37 with armor = true, offhand 40) with the inventory slot {@code inv} (0-35). */
    public static class Op {
        public final int hotbar, inv;
        /** Item that must be in that slot after the swap. */
        public final Item expect;
        /** Item that was in that slot before the swap. */
        public final Item hotbarBefore;
        /** Armor swaps compare the whole stack (enchantments count), not only the item type. */
        public final boolean armor;
        public final ItemStack expectStack, beforeStack;

        public Op(int hotbar, int inv, Item expect, Item hotbarBefore) {
            this(hotbar, inv, expect, hotbarBefore, false, null, null);
        }

        private Op(int hotbar, int inv, Item expect, Item hotbarBefore, boolean armor, ItemStack expectStack, ItemStack beforeStack) {
            this.hotbar = hotbar;
            this.inv = inv;
            this.expect = expect;
            this.hotbarBefore = hotbarBefore;
            this.armor = armor;
            this.expectStack = expectStack;
            this.beforeStack = beforeStack;
        }

        /** Swap armor slot {@code armorIndex} (0 boots, 1 leggings, 2 chestplate, 3 helmet) with inventory slot {@code inv}. */
        public static Op armor(int armorIndex, int inv, ItemStack expectStack, ItemStack beforeStack) {
            return new Op(36 + armorIndex, inv, expectStack.getItem(), beforeStack.getItem(), true, expectStack, beforeStack);
        }

        /** The swap that undoes this one. */
        public Op reversed() {
            if (armor) return new Op(hotbar, inv, hotbarBefore, expect, true, beforeStack, expectStack);
            return new Op(hotbar, inv, hotbarBefore, expect);
        }

        /** True if the slot holds what this swap should have put there. */
        public boolean matches(ItemStack actual) {
            if (armor && expectStack != null) return ItemStack.isSameItemSameComponents(actual, expectStack);
            return actual.getItem() == expect;
        }

        /** True if the slot still holds what it held before the swap (so the swap has not happened or was undone). */
        public boolean matchesBefore(ItemStack actual) {
            if (armor && beforeStack != null) return ItemStack.isSameItemSameComponents(actual, beforeStack);
            return actual.getItem() == hotbarBefore;
        }
    }

    public boolean openScreen = true;
    public boolean totalMode = false;
    public int totalMs = 100;
    public int waitBeforeClick = 40;
    public int clickDelay = 30;
    public int verifyWait = 80;
    public boolean waitUntilStill = false;
    /** Spin-wait the last few milliseconds before a click or the close, so the time is exact and not rounded to a frame. */
    public boolean exact = true;
    private static final long SPIN_MS = 40;

    /** Step mode: close the screen right after the swaps and check/redo them afterwards in the background. */
    public boolean backgroundVerify = false;
    /** Do not check the swaps at all (the caller checks the result itself). */
    public boolean skipCheck = false;

    /** Number of swaps that still did not work after the retries (Step mode only). */
    public int failed;
    /** How long the last visit lasted (screen opened to screen closed), in ms. */
    public long duration;

    /** Only one inventory visit may run at a time (X-Bow Cart, Silent Totem and the refill key share this). */
    private static InvSession owner;

    private final Minecraft client = Minecraft.getInstance();
    private List<Op> ops = new ArrayList<>();
    private int phase, index, retries;
    private long visitStart, nextClick, closeAt, verifyAt, lockWaitStart;
    private boolean running;

    // Background work: visits that run without an owner, and the checks that run after a visit.
    private static final List<InvSession> runners = new ArrayList<>();
    private static final List<InvSession> checkers = new ArrayList<>();
    private List<Op> checkOps = new ArrayList<>();
    private long checkAt, checkDeadline;
    private int checkRound;

    /** What is in the slot of this swap right now (armor and offhand are read the safe way). */
    public static ItemStack stackAt(Minecraft client, Op op) {
        if (op.armor) return client.player.getItemBySlot(armorSlot(op.hotbar - 36));
        if (op.hotbar == 40) return client.player.getOffhandItem();
        return client.player.getInventory().getItem(op.hotbar);
    }

    /** Meteor's armor index: 0 boots, 1 leggings, 2 chestplate, 3 helmet. */
    public static EquipmentSlot armorSlot(int index) {
        return switch (index) {
            case 0 -> EquipmentSlot.FEET;
            case 1 -> EquipmentSlot.LEGS;
            case 2 -> EquipmentSlot.CHEST;
            default -> EquipmentSlot.HEAD;
        };
    }

    private static void spinUntil(long targetMs) {
        while (System.currentTimeMillis() < targetMs) Thread.onSpinWait();
    }

    /**
     * Sets the waits for one visit. Total mode uses one total time for the whole visit; Step mode
     * uses the three given values.
     */
    public void timing(boolean totalMode, int totalMs, int wait, int click, int verify, int opCount) {
        this.totalMode = totalMode;
        this.totalMs = totalMs;
        this.waitBeforeClick = wait;
        this.clickDelay = click;
        this.verifyWait = verify;
    }

    public boolean isRunning() {
        return running;
    }

    /** Starts a visit that nobody has to tick: {@link #backgroundTick(long)} runs it (the module may be off). */
    public static void runInBackground(InvSession session, List<Op> ops) {
        session.start(ops, System.currentTimeMillis());
        if (!runners.contains(session)) runners.add(session);
    }

    /** Hands a running visit over to {@link #backgroundTick(long)} (used when the module is switched off mid-visit). */
    public static void continueInBackground(InvSession session) {
        if (!runners.contains(session)) runners.add(session);
    }

    /** Call every frame from an always-on listener: runs background visits and the after-visit checks. */
    /** True while an inventory visit is running (other code should not touch the inventory then). */
    public static boolean busy() {
        return owner != null && owner.running;
    }

    public static void backgroundTick(long now) {
        for (int i = runners.size() - 1; i >= 0; i--) {
            if (runners.get(i).tick(now)) runners.remove(i);
        }
        for (int i = checkers.size() - 1; i >= 0; i--) {
            if (checkers.get(i).checkStep(now)) checkers.remove(i);
        }
    }

    /**
     * After-visit check, done without opening anything: swaps the server undid are sent again (up to
     * 2 rounds). Returns true when it is finished.
     */
    private boolean checkStep(long now) {
        Minecraft mc = client;
        if (mc.player == null || mc.level == null) return true;
        if (now < checkAt) return false;

        // Another visit is using the inventory right now, or another screen is open: wait a little.
        boolean busy = (owner != null && owner.running)
            || (mc.screen != null && !(mc.screen instanceof InventoryScreen));
        if (busy) {
            if (now > checkDeadline) return true;
            checkAt = now + 50;
            return false;
        }

        List<Op> redo = new ArrayList<>();
        for (Op op : checkOps) {
            ItemStack actual = stackAt(mc, op);
            if (op.matches(actual)) continue;
            if (op.matchesBefore(actual)) redo.add(op);
        }
        if (redo.isEmpty() || checkRound >= 2) return true;

        for (Op op : redo) perform(op);
        checkRound++;
        checkOps = redo;
        checkAt = now + Math.max(60, verifyWait);
        checkDeadline = now + 4000;
        return false;
    }

    private void perform(Op op) {
        if (op.armor) InvUtils.move().from(op.inv).toArmor(op.hotbar - 36);
        else if (op.inv < 9) InvUtils.quickSwap().fromId(op.hotbar).toHotbar(op.inv);
        else InvUtils.quickSwap().fromId(op.hotbar).to(op.inv);
    }

    public void start(List<Op> list, long now) {
        ops = new ArrayList<>(list);
        phase = -1;   // waiting for the inventory lock
        index = 0;
        retries = 0;
        failed = 0;
        lockWaitStart = now;
        running = true;
        checkOps = new ArrayList<>(list);
    }

    public void abort() {
        if (running && phase >= 0) closeScreen();
        running = false;
        release();
    }

    private void release() {
        if (owner == this) owner = null;
    }

    /** Call every frame. Returns true once the visit is completely finished (screen closed). */
    public boolean tick(long now) {
        if (!running) return true;
        if (client.player == null) {
            running = false;
            release();
            return true;
        }

        // Several phases can pass in one call, so nothing is lost to frame boundaries.
        for (int guard = 0; guard < 16; guard++) {
            int r = stepOnce(System.currentTimeMillis());
            if (r == 2) return true;
            if (r == 0) return false;
        }
        return false;
    }

    /** 0 = waiting, 1 = moved to the next phase, 2 = finished. */
    private int stepOnce(long now) {
        switch (phase) {
            case -1 -> {
                if (owner != null && owner != this && owner.running) {
                    if (now - lockWaitStart > 3000) {
                        failed = ops.size();
                        running = false;
                        return 2;
                    }
                    return 0;
                }
                owner = this;
                phase = 0;
                return 1;
            }
            case 0 -> {
                if (ops.isEmpty()) {
                    running = false;
                    release();
                    return 2;
                }
                if (openScreen) client.setScreen(new InventoryScreen(client.player));
                visitStart = now;
                nextClick = now + (totalMode ? Math.round(totalMs * 0.25) : waitBeforeClick);
                closeAt = now + totalMs;
                phase = 1;
                return 1;
            }
            case 1 -> {
                long n = now;
                if (n < nextClick) {
                    if (!(exact && nextClick - n <= SPIN_MS)) return 0;
                    spinUntil(nextClick);
                    n = System.currentTimeMillis();
                }
                boolean ready = !waitUntilStill || isStill() || n - visitStart > 1500;
                if (!ready) return 0;
                phase = 2;
                return 1;
            }
            case 2 -> {
                Op op = ops.get(index++);
                perform(op);
                now = System.currentTimeMillis();

                long gap = totalMode ? (ops.size() > 1 ? Math.round(totalMs * 0.5 / (ops.size() - 1)) : 0) : clickDelay;
                nextClick = now + gap;
                if (index < ops.size()) {
                    phase = 1;
                } else if (totalMode) {
                    phase = 4;
                } else if (backgroundVerify || skipCheck) {
                    phase = 5;
                } else {
                    verifyAt = now + verifyWait;
                    phase = 3;
                }
                return 1;
            }
            case 3 -> {
                if (now < verifyAt) return 0;

                // Redo only the swaps the server undid (the slot is back to how it was before).
                // A slot that is neither "before" nor "after" was changed by something else: leave it.
                List<Op> redo = new ArrayList<>();
                for (Op op : ops) {
                    ItemStack actual = stackAt(client, op);
                    if (op.matches(actual)) continue;
                    if (op.matchesBefore(actual) && retries < 2) redo.add(op);
                    else failed++;
                }
                if (redo.isEmpty()) {
                    phase = 5;
                } else {
                    retries++;
                    ops = redo;
                    index = 0;
                    nextClick = now;
                    phase = 1;
                }
                return 1;
            }
            case 4 -> {
                if (now < closeAt) {
                    if (!(exact && closeAt - now <= SPIN_MS)) return 0;
                    spinUntil(closeAt);
                }
                phase = 5;
                return 1;
            }
            default -> {
                closeScreen();
                now = System.currentTimeMillis();
                duration = now - visitStart;
                running = false;
                release();
                // Total mode and background mode never wait for the server inside the visit, so the
                // result is checked (and failed swaps redone) afterwards, unless the caller checks itself.
                if (!skipCheck && (totalMode || backgroundVerify) && failed == 0) {
                    checkRound = 0;
                    checkAt = now + Math.max(60, verifyWait);
                    checkDeadline = now + 4000;
                    if (!checkers.contains(this)) checkers.add(this);
                }
                return 2;
            }
        }
    }

    private boolean isStill() {
        Vec3 dm = client.player.getDeltaMovement();
        return Math.hypot(dm.x, dm.z) < 0.02;
    }

    private void closeScreen() {
        if (client.player != null && client.screen instanceof InventoryScreen) client.player.closeContainer();
    }
}
