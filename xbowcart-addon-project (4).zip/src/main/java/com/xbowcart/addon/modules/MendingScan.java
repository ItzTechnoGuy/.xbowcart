package com.xbowcart.addon.modules;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.phys.AABB;

import java.util.HashSet;
import java.util.Set;

/**
 * Mending Scan by ItzTechnoGuy: shows which players around you wear armor with Mending, with a box
 * around them and (once per player) a message in the chat.
 */
public class MendingScan extends Module {
    private final Minecraft client = Minecraft.getInstance();
    private final Set<Integer> announced = new HashSet<>();

    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Double> range = sg.add(new DoubleSetting.Builder()
        .name("range")
        .description("Only look at players closer than this, in blocks.")
        .defaultValue(64.0).range(8.0, 256.0).sliderRange(8.0, 128.0).decimalPlaces(0)
        .build());

    private final Setting<Integer> minPieces = sg.add(new IntSetting.Builder()
        .name("min-pieces")
        .description("How many armor pieces (1-4) must have Mending before a player is shown.")
        .defaultValue(1).range(1, 4).sliderRange(1, 4)
        .build());

    private final Setting<Boolean> drawBox = sg.add(new BoolSetting.Builder()
        .name("draw-box")
        .description("Draw a box around players with Mending armor.")
        .defaultValue(true).build());

    private final Setting<SettingColor> color = sg.add(new ColorSetting.Builder()
        .name("color")
        .description("Colour of the box.")
        .defaultValue(new SettingColor(255, 170, 0, 255))
        .visible(drawBox::get).build());

    private final Setting<Boolean> chatMessage = sg.add(new BoolSetting.Builder()
        .name("chat-message")
        .description("Write the player's name in the chat once when you first see their Mending armor.")
        .defaultValue(true).build());

    public MendingScan() {
        super(Categories.Render, "mending-scan", "Shows players whose armor has Mending. By ItzTechnoGuy.");
    }

    @Override
    public void onActivate() {
        announced.clear();
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (client.player == null || client.level == null) return;

        for (AbstractClientPlayer p : client.level.players()) {
            if (p == client.player || p.isRemoved()) continue;
            if (p.distanceTo(client.player) > range.get()) continue;

            int pieces = mendingPieces(p);
            if (pieces < minPieces.get()) continue;

            if (chatMessage.get() && announced.add(p.getId())) {
                info(p.getName().getString() + " has Mending on " + pieces + " armor piece(s).");
            }
            if (drawBox.get()) drawBox(event, p);
        }
    }

    private int mendingPieces(AbstractClientPlayer p) {
        int count = 0;
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        for (EquipmentSlot slot : slots) {
            ItemStack stack = p.getItemBySlot(slot);
            if (stack.isEmpty()) continue;
            ItemEnchantments enchantments = stack.getOrDefault(DataComponents.ENCHANTMENTS, ItemEnchantments.EMPTY);
            for (Holder<Enchantment> h : enchantments.keySet()) {
                if (h.is(Enchantments.MENDING)) {
                    count++;
                    break;
                }
            }
        }
        return count;
    }

    private void drawBox(Render3DEvent event, AbstractClientPlayer p) {
        double ox = Mth.lerp(event.tickDelta, p.xo, p.getX()) - p.getX();
        double oy = Mth.lerp(event.tickDelta, p.yo, p.getY()) - p.getY();
        double oz = Mth.lerp(event.tickDelta, p.zo, p.getZ()) - p.getZ();
        AABB b = p.getBoundingBox();
        double x1 = b.minX + ox, y1 = b.minY + oy, z1 = b.minZ + oz;
        double x2 = b.maxX + ox, y2 = b.maxY + oy, z2 = b.maxZ + oz;
        SettingColor c = color.get();

        // bottom, top and the four vertical edges
        event.renderer.line(x1, y1, z1, x2, y1, z1, c);
        event.renderer.line(x2, y1, z1, x2, y1, z2, c);
        event.renderer.line(x2, y1, z2, x1, y1, z2, c);
        event.renderer.line(x1, y1, z2, x1, y1, z1, c);
        event.renderer.line(x1, y2, z1, x2, y2, z1, c);
        event.renderer.line(x2, y2, z1, x2, y2, z2, c);
        event.renderer.line(x2, y2, z2, x1, y2, z2, c);
        event.renderer.line(x1, y2, z2, x1, y2, z1, c);
        event.renderer.line(x1, y1, z1, x1, y2, z1, c);
        event.renderer.line(x2, y1, z1, x2, y2, z1, c);
        event.renderer.line(x2, y1, z2, x2, y2, z2, c);
        event.renderer.line(x1, y1, z2, x1, y2, z2, c);
    }
}
