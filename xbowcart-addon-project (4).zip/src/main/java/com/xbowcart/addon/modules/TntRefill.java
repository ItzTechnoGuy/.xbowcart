package com.xbowcart.addon.modules;

import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;

/**
 * TNT Cart Refill by ItzTechnoGuy: bind a key to this module. Each press opens the inventory,
 * swaps a TNT minecart into your hotbar slot with the hotbar-number swap (not shift-click), and
 * closes it. It switches itself off right away; the swap runs in the background, so the key can be
 * pressed again at any time.
 */
public class TntRefill extends Module {
    public enum Timing { Step, Total }

    private final Minecraft client = Minecraft.getInstance();
    private final InvSession session = new InvSession();

    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Integer> hotbarSlot = sg.add(new IntSetting.Builder()
        .name("hotbar-slot")
        .description("Hotbar slot (1-9) the TNT minecart should end up in.")
        .defaultValue(7).range(1, 9).sliderRange(1, 9).build());

    private final Setting<Boolean> useLastSlot = sg.add(new BoolSetting.Builder()
        .name("use-slot-of-last-cart")
        .description("On: use the hotbar slot the last TNT minecart of X-Bow Cart came from (falls back to the slot above). Off: always the slot above.")
        .defaultValue(false).build());

    private final Setting<Boolean> openInventory = sg.add(new BoolSetting.Builder()
        .name("open-inventory")
        .description("Show the inventory screen while swapping.")
        .defaultValue(true).build());

    private final Setting<Timing> timing = sg.add(new EnumSetting.Builder<Timing>()
        .name("timing")
        .description("Step: set the waits yourself. Total: one time for the whole visit (open to closed), checked afterwards.")
        .defaultValue(Timing.Total).build());

    private final Setting<Integer> totalTime = sg.add(new IntSetting.Builder()
        .name("total-time")
        .description("Time the inventory stays open, in ms.")
        .defaultValue(100).range(20, 2000).sliderRange(20, 500)
        .visible(() -> timing.get() == Timing.Total).build());

    private final Setting<Integer> waitBeforeClick = sg.add(new IntSetting.Builder()
        .name("wait-before-click")
        .description("Time between opening the inventory and the swap, in ms.")
        .defaultValue(40).range(0, 500).sliderRange(0, 200)
        .visible(() -> timing.get() == Timing.Step).build());

    private final Setting<Integer> verifyWait = sg.add(new IntSetting.Builder()
        .name("verify-wait")
        .description("Time before the swap is checked (and sent again if the server undid it), in ms.")
        .defaultValue(80).range(20, 500).sliderRange(20, 300).build());

    private final Setting<Boolean> waitUntilStill = sg.add(new BoolSetting.Builder()
        .name("wait-until-still")
        .description("Wait (up to 1.5 s) until you have stopped moving before swapping.")
        .defaultValue(false).build());

    public TntRefill() {
        super(Categories.Combat, "tnt-cart-refill", "One key press: put a TNT minecart from the inventory into a hotbar slot. By ItzTechnoGuy.");
    }

    @Override
    public void onActivate() {
        try {
            start();
        } finally {
            toggle();   // the swap itself runs in the background
        }
    }

    private void start() {
        if (client.player == null) return;
        if (session.isRunning()) return;

        int last = XBowCart.lastCartSlot;
        int slot = (useLastSlot.get() && last >= 0) ? last : hotbarSlot.get() - 1;

        ItemStack inSlot = client.player.getInventory().getItem(slot);
        if (inSlot.is(Items.TNT_MINECART)) {
            info("Hotbar slot " + (slot + 1) + " already has TNT minecarts.");
            return;
        }

        int best = -1, bestCount = 0;
        for (int i = 9; i <= 35; i++) {
            ItemStack s = client.player.getInventory().getItem(i);
            if (s.is(Items.TNT_MINECART) && s.getCount() > bestCount) {
                best = i;
                bestCount = s.getCount();
            }
        }
        if (best < 0) {
            warning("No TNT minecart in the inventory.");
            return;
        }

        List<InvSession.Op> ops = new ArrayList<>();
        ops.add(new InvSession.Op(slot, best, Items.TNT_MINECART, inSlot.getItem()));

        session.openScreen = openInventory.get();
        session.waitUntilStill = waitUntilStill.get();
        session.timing(timing.get() == Timing.Total, totalTime.get(), waitBeforeClick.get(), 0, verifyWait.get(), 1);
        // The server needs a round trip to confirm (or undo) the swap, so never check earlier than that.
        session.verifyWait = Math.max(session.verifyWait, 2 * latency() + 50);
        InvSession.runInBackground(session, ops);
    }

    private int latency() {
        if (client.getConnection() == null || client.player == null) return 0;
        PlayerInfo info = client.getConnection().getPlayerInfo(client.player.getUUID());
        return info == null ? 0 : Math.max(0, info.getLatency());
    }
}
