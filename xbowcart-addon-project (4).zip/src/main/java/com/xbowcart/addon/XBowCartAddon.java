package com.xbowcart.addon;

import com.xbowcart.addon.modules.AreaMiner;
import com.xbowcart.addon.modules.MendingScan;
import com.xbowcart.addon.modules.SilentTotem;
import com.xbowcart.addon.modules.TntRefill;
import com.xbowcart.addon.modules.XBowCart;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Modules;

import java.lang.invoke.MethodHandles;

/** X-Bow Cart addon by ItzTechnoGuy. */
public class XBowCartAddon extends MeteorAddon {
    @Override
    public void onInitialize() {
        // Lets Meteor's event bus call @EventHandler methods inside this package.
        MeteorClient.EVENT_BUS.registerLambdaFactory("com.xbowcart.addon",
            (lookupInMethod, klass) -> (MethodHandles.Lookup) lookupInMethod.invoke(null, klass, MethodHandles.lookup()));

        Modules.get().add(new XBowCart());
        Modules.get().add(new SilentTotem());
        Modules.get().add(new MendingScan());
        Modules.get().add(new AreaMiner());
        Modules.get().add(new TntRefill());

        MeteorClient.EVENT_BUS.subscribe(new Overlay());
    }

    @Override
    public void onRegisterCategories() {
    }

    @Override
    public String getPackage() {
        return "com.xbowcart.addon";
    }
}
