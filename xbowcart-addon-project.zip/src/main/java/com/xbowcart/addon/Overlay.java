package com.xbowcart.addon;

import com.xbowcart.addon.modules.XBowCart;
import meteordevelopment.meteorclient.events.meteor.KeyEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.misc.input.KeyAction;
import meteordevelopment.orbit.EventHandler;

/**
 * Always-on listener (it works even when the X-Bow Cart module is switched off): it draws the
 * placement circle, listens for the refill key and runs the manual refill.
 */
public class Overlay {
    @EventHandler
    private void onRender(Render3DEvent event) {
        XBowCart module = Modules.get().get(XBowCart.class);
        if (module == null) return;
        module.backgroundTick(System.currentTimeMillis());
        module.renderCircle(event);
    }

    @EventHandler
    private void onKey(KeyEvent event) {
        if (event.action != KeyAction.Press) return;
        XBowCart module = Modules.get().get(XBowCart.class);
        if (module == null) return;
        module.onGlobalKey(event.key(), event.modifiers());
    }
}
