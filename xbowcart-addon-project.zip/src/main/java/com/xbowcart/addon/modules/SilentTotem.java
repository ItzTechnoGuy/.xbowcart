package com.xbowcart.addon.modules;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;

/**
 * Silent Totem by ItzTechnoGuy.
 *
 * Whenever your offhand has no totem of undying (for example right after one popped), it opens the
 * inventory, swaps a totem into the offhand with the offhand swap click (the same as hovering the
 * totem and pressing F), checks that it worked (redoes it if the server undid it) and closes the
 * inventory. If the totem pops again, it does it again.
 */
public class SilentTotem extends Module {
    public enum Timing { Step, Total }

    private static final int OFFHAND = 40;

    private final Minecraft client = Minecraft.getInstance();
    private final InvSession session = new InvSession();

    private final SettingGroup sg = settings.getDefaultGroup();
    private final SettingGroup sgInv = settings.createGroup("Inventory");

    private final Setting<Double> health = sg.add(new DoubleSetting.Builder()
        .name("health")
        .description("Only put a totem in when your health (hearts x 2 + absorption) is at or below this. 36 = always.")
        .defaultValue(36.0)
        .range(1.0, 36.0)
        .sliderRange(1.0, 36.0)
        .decimalPlaces(0)
        .build());

    private final Setting<Integer> reactionDelay = sg.add(new IntSetting.Builder()
        .name("reaction-delay")
        .description("Time between the offhand becoming empty and the inventory opening, in ms.")
        .defaultValue(0)
        .range(0, 1000)
        .sliderRange(0, 500)
        .build());

    private final Setting<Integer> cooldown = sg.add(new IntSetting.Builder()
        .name("cooldown")
        .description("Minimum time between two totem swaps, in ms.")
        .defaultValue(100)
        .range(0, 2000)
        .sliderRange(0, 1000)
        .build());

    private final Setting<Boolean> useHotbar = sg.add(new BoolSetting.Builder()
        .name("use-hotbar")
        .description("Also take totems from the hotbar (the main inventory is always searched first).")
        .defaultValue(true)
        .build());

    private final Setting<Boolean> notify = sg.add(new BoolSetting.Builder()
        .name("chat-message")
        .description("Print a message in the chat when a totem was put in or none is left.")
        .defaultValue(false)
        .build());

    private final Setting<Boolean> openInventory = sgInv.add(new BoolSetting.Builder()
        .name("open-inventory")
        .description("Show the inventory screen while swapping.")
        .defaultValue(true)
        .build());

    private final Setting<Timing> timing = sgInv.add(new EnumSetting.Builder<Timing>()
        .name("timing")
        .description("Step: set each wait yourself. Total: set one time for the whole inventory visit.")
        .defaultValue(Timing.Step)
        .build());

    private final Setting<Integer> totalTime = sgInv.add(new IntSetting.Builder()
        .name("total-time")
        .description("Time for the whole inventory visit (open, swap, check, close), in ms.")
        .defaultValue(120)
        .range(20, 1500)
        .sliderRange(20, 600)
        .visible(() -> timing.get() == Timing.Total)
        .build());

    private final Setting<Integer> waitBeforeClick = sgInv.add(new IntSetting.Builder()
        .name("wait-before-click")
        .description("Time between opening the inventory and the swap, in ms.")
        .defaultValue(40)
        .range(0, 500)
        .sliderRange(0, 200)
        .visible(() -> timing.get() == Timing.Step)
        .build());

    private final Setting<Integer> verifyWait = sgInv.add(new IntSetting.Builder()
        .name("verify-wait")
        .description("Time between the swap and the check that it worked, in ms.")
        .defaultValue(80)
        .range(20, 500)
        .sliderRange(20, 300)
        .visible(() -> timing.get() == Timing.Step)
        .build());

    private final Setting<Boolean> waitUntilStill = sgInv.add(new BoolSetting.Builder()
        .name("wait-until-still")
        .description("Wait (up to 1.5 s) until you have stopped moving before swapping.")
        .defaultValue(false)
        .build());

    private boolean running;
    private long missingSince, lastDone;
    private boolean warnedNoTotem;

    public SilentTotem() {
        super(Categories.Combat, "silent-totem", "Puts a totem of undying into the offhand through the inventory whenever it is empty. By ItzTechnoGuy.");
    }

    @Override
    public void onActivate() {
        running = false;
        missingSince = 0;
        lastDone = 0;
        warnedNoTotem = false;
    }

    @Override
    public void onDeactivate() {
        session.abort();
        running = false;
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (client.player == null || client.level == null) return;
        long now = System.currentTimeMillis();

        if (running) {
            if (session.tick(now)) {
                running = false;
                lastDone = now;
                if (session.failed > 0) warning("The server did not accept the totem swap.");
                else if (notify.get()) info("Totem put in the offhand.");
            }
            return;
        }

        if (now - lastDone < cooldown.get()) return;

        if (client.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) {
            missingSince = 0;
            warnedNoTotem = false;
            return;
        }

        double hp = client.player.getHealth() + client.player.getAbsorptionAmount();
        if (hp > health.get()) return;

        // Do not interrupt other screens (chests, chat, menus).
        if (client.screen != null && !(client.screen instanceof InventoryScreen)) return;

        if (missingSince == 0) missingSince = now;
        if (now - missingSince < reactionDelay.get()) return;

        int src = findTotem();
        if (src < 0) {
            if (notify.get() && !warnedNoTotem) warning("No totem of undying left.");
            warnedNoTotem = true;
            return;
        }

        List<InvSession.Op> ops = new ArrayList<>();
        ops.add(new InvSession.Op(OFFHAND, src, Items.TOTEM_OF_UNDYING, client.player.getOffhandItem().getItem()));

        session.openScreen = openInventory.get();
        session.waitUntilStill = waitUntilStill.get();
        session.timing(timing.get() == Timing.Total, totalTime.get(), waitBeforeClick.get(), 0, verifyWait.get(), 1);
        session.start(ops, now);
        running = true;
    }

    /** Totem slot: main inventory first (9-35), then the hotbar (0-8) if allowed. */
    private int findTotem() {
        for (int i = 9; i <= 35; i++) {
            ItemStack s = client.player.getInventory().getItem(i);
            if (s.is(Items.TOTEM_OF_UNDYING)) return i;
        }
        if (useHotbar.get()) {
            for (int i = 0; i < 9; i++) {
                ItemStack s = client.player.getInventory().getItem(i);
                if (s.is(Items.TOTEM_OF_UNDYING)) return i;
            }
        }
        return -1;
    }
}
