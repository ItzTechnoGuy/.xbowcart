package com.xbowcart.addon.modules;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BlockListSetting;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.ItemListSetting;
import meteordevelopment.meteorclient.settings.KeybindSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Area Miner by ItzTechnoGuy.
 *
 * You mark two corners (look at a block and press the corner key), then switch the module on. It
 * mines every block inside the box and nothing outside it. When the box is empty it waits until the
 * blocks have respawned (for example a mine that resets) and mines it again.
 *
 * Normal mode: every block is mined until it breaks. Instant mode: blocks that your current tool
 * breaks in one tick are broken a few per tick, anything slower is mined the normal way.
 * It uses the game's own break calls, like a player holding the attack button, and it only touches
 * blocks you can reach from where you stand.
 */
public class AreaMiner extends Module {
    public enum Mode { Normal, Instant }

    public enum Order { Nearest, BottomUp, TopDown, TwoLayersThenUp }

    private enum Stage { MINING, WAIT_RESPAWN, WALKING }

    private static final int MAX_VOLUME = 100_000;

    private final Minecraft client = Minecraft.getInstance();

    private final SettingGroup sg = settings.getDefaultGroup();
    private final SettingGroup sgArea = settings.createGroup("Area");
    private final SettingGroup sgRepeat = settings.createGroup("Repeat");
    private final SettingGroup sgMove = settings.createGroup("Movement");
    private final SettingGroup sgItems = settings.createGroup("Items");

    // ---- Mining

    private final Setting<Mode> mode = sg.add(new EnumSetting.Builder<Mode>()
        .name("mode")
        .description("Normal: every block is mined until it breaks. Instant: blocks your tool breaks in one tick are broken several per tick, slower ones the normal way.")
        .defaultValue(Mode.Instant).build());

    private final Setting<Integer> blocksPerTick = sg.add(new IntSetting.Builder()
        .name("blocks-per-tick")
        .description("Instant mode: how many instantly breakable blocks are broken per game tick (1 = like holding the attack button).")
        .defaultValue(1).range(1, 20).sliderRange(1, 10)
        .visible(() -> mode.get() == Mode.Instant).build());

    private final Setting<Boolean> fallbackNormal = sg.add(new BoolSetting.Builder()
        .name("mine-slow-blocks")
        .description("Instant mode: also mine the blocks that do not break instantly (for example quartz in a netherrack area) the normal way.")
        .defaultValue(true)
        .visible(() -> mode.get() == Mode.Instant).build());

    private final Setting<Order> order = sg.add(new EnumSetting.Builder<Order>()
        .name("order")
        .description("Nearest: always the closest block. BottomUp / TopDown: layer by layer. TwoLayersThenUp: the lowest two layers first, then the rest from the bottom up.")
        .defaultValue(Order.TwoLayersThenUp).build());

    private final Setting<Boolean> autoTool = sg.add(new BoolSetting.Builder()
        .name("auto-tool")
        .description("Use the hotbar tool that mines the current block fastest.")
        .defaultValue(true).build());

    private final Setting<Boolean> stopLowTool = sg.add(new BoolSetting.Builder()
        .name("stop-on-low-durability")
        .description("Stop when the tool in your hand has 2 or fewer uses left.")
        .defaultValue(true).build());

    private final Setting<Double> reachExtra = sg.add(new DoubleSetting.Builder()
        .name("reach-extra")
        .description("Added to your real block reach (the server tolerates about 1 extra block). 0 = only what you can normally reach.")
        .defaultValue(0.0).range(0.0, 1.0).sliderRange(0.0, 1.0).decimalPlaces(1).build());

    private final Setting<Integer> maxBlockTime = sg.add(new IntSetting.Builder()
        .name("max-block-time")
        .description("Skip a block that is still not broken after this long, in ms.")
        .defaultValue(6000).range(500, 30000).sliderRange(1000, 15000).build());

    private final Setting<Boolean> lookAtBlock = sg.add(new BoolSetting.Builder()
        .name("look-at-block")
        .description("Turn the camera smoothly toward the block being mined.")
        .defaultValue(true).build());

    private final Setting<Integer> rotateTime = sg.add(new IntSetting.Builder()
        .name("rotate-time")
        .description("How long the camera takes to turn to a new block, in ms.")
        .defaultValue(80).range(0, 500).sliderRange(0, 300)
        .visible(lookAtBlock::get).build());

    // ---- Area

    private final Setting<Keybind> pos1Key = sgArea.add(new KeybindSetting.Builder()
        .name("corner-1-key")
        .description("Look at a block and press this key to set the first corner.")
        .defaultValue(Keybind.none()).build());

    private final Setting<Keybind> pos2Key = sgArea.add(new KeybindSetting.Builder()
        .name("corner-2-key")
        .description("Look at the opposite corner block and press this key to set the second corner.")
        .defaultValue(Keybind.none()).build());

    private final Setting<Keybind> clearKey = sgArea.add(new KeybindSetting.Builder()
        .name("clear-selection-key")
        .description("Press this key to forget the selection.")
        .defaultValue(Keybind.none()).build());

    private final Setting<Double> selectRange = sgArea.add(new DoubleSetting.Builder()
        .name("select-range")
        .description("How far away the block can be when you set a corner.")
        .defaultValue(32.0).range(4.0, 128.0).sliderRange(4.0, 64.0).decimalPlaces(0).build());

    private final Setting<Boolean> showBox = sgArea.add(new BoolSetting.Builder()
        .name("show-box")
        .description("Draw the selected area.")
        .defaultValue(true).build());

    private final Setting<SettingColor> boxColor = sgArea.add(new ColorSetting.Builder()
        .name("box-color")
        .description("Colour of the selection box.")
        .defaultValue(new SettingColor(255, 80, 80, 255))
        .visible(showBox::get).build());

    // ---- Repeat

    private final Setting<Boolean> repeat = sgRepeat.add(new BoolSetting.Builder()
        .name("repeat")
        .description("When the area is empty, wait for it to respawn and mine it again.")
        .defaultValue(true).build());

    private final Setting<Integer> respawnPercent = sgRepeat.add(new IntSetting.Builder()
        .name("respawn-percent")
        .description("Start again once this share of the area's blocks (compared with the fullest it has been) is back.")
        .defaultValue(90).range(1, 100).sliderRange(1, 100)
        .visible(repeat::get).build());

    private final Setting<Integer> maxCycles = sgRepeat.add(new IntSetting.Builder()
        .name("max-cycles")
        .description("Stop after this many full clears. 0 = never stop.")
        .defaultValue(0).range(0, 1000).sliderRange(0, 100)
        .visible(repeat::get).build());

    // ---- Movement

    private final Setting<Boolean> reposition = sgMove.add(new BoolSetting.Builder()
        .name("reposition")
        .description("When nothing is in reach but blocks are left, walk to the closest spot from which the most remaining blocks can be reached, then carry on mining.")
        .defaultValue(true).build());

    private final Setting<Integer> repositionRadius = sgMove.add(new IntSetting.Builder()
        .name("search-radius")
        .description("How far around the nearest remaining block the module looks for a place to stand, in blocks.")
        .defaultValue(4).range(1, 8).sliderRange(1, 8)
        .visible(reposition::get).build());

    private final Setting<Integer> walkTimeout = sgMove.add(new IntSetting.Builder()
        .name("walk-timeout")
        .description("Give up a walk that takes longer than this, in ms.")
        .defaultValue(6000).range(1000, 20000).sliderRange(1000, 10000)
        .visible(reposition::get).build());

    // ---- Items

    private final Setting<List<Block>> skipBlocks = sgItems.add(new BlockListSetting.Builder()
        .name("skip-blocks")
        .description("Blocks that are never mined (for example ancient debris, if you only want the netherite blocks in your inventory).")
        .defaultValue(new ArrayList<>()).build());

    private final Setting<Boolean> autoDrop = sgItems.add(new BoolSetting.Builder()
        .name("auto-drop")
        .description("Drop chosen items automatically once you hold enough stacks of them.")
        .defaultValue(false).build());

    private final Setting<List<Item>> dropItems = sgItems.add(new ItemListSetting.Builder()
        .name("drop-items")
        .description("The items to drop.")
        .defaultValue(new ArrayList<>())
        .visible(autoDrop::get).build());

    private final Setting<Integer> dropStacks = sgItems.add(new IntSetting.Builder()
        .name("drop-after-stacks")
        .description("Drop an item as soon as you hold this many stacks of it (everything of that item in your inventory is dropped).")
        .defaultValue(5).range(1, 36).sliderRange(1, 36)
        .visible(autoDrop::get).build());

    private final Setting<Boolean> dropOpenInventory = sgItems.add(new BoolSetting.Builder()
        .name("open-inventory-to-drop")
        .description("On: the inventory screen opens while dropping. Off: the items are dropped without opening it.")
        .defaultValue(false)
        .visible(autoDrop::get).build());

    private final Setting<Boolean> stopWhenFull = sgItems.add(new BoolSetting.Builder()
        .name("stop-when-inventory-full")
        .description("Stop when your inventory has no empty slot left.")
        .defaultValue(true).build());

    // ---- State

    private BlockPos corner1, corner2;
    private final List<BlockPos> targets = new ArrayList<>();
    private final Set<BlockPos> skipped = new HashSet<>();
    private Stage stage = Stage.MINING;
    private BlockPos current;
    private long currentStart, lastScan, lastReachMessage;
    private int cycles, baseline;
    private boolean aiming;
    private long rotStart;
    private float startYaw, startPitch, aimYaw, aimPitch;
    private BlockPos standSpot;
    private long lastDropCheck, dropAt;
    private int dropPhase;
    private final List<Integer> dropSlots = new ArrayList<>();
    private long walkStart, walkBlockedUntil;
    private int walkFailures;

    public AreaMiner() {
        super(Categories.World, "area-miner", "Mines everything inside a box you mark, and again after it respawns. By ItzTechnoGuy.");
    }

    @Override
    public void onActivate() {
        if (client.player == null || client.level == null) {
            toggle();
            return;
        }
        if (corner1 == null || corner2 == null) {
            error("Set both corners first (look at a block and press the corner keys).");
            toggle();
            return;
        }
        long volume = volume();
        if (volume > MAX_VOLUME) {
            error("The area is too big (" + volume + " blocks, the limit is " + MAX_VOLUME + ").");
            toggle();
            return;
        }

        cycles = 0;
        baseline = 0;
        current = null;
        aiming = false;
        skipped.clear();
        standSpot = null;
        walkBlockedUntil = 0;
        walkFailures = 0;
        dropPhase = 0;
        lastDropCheck = 0;
        stage = Stage.MINING;
        int count = rebuildTargets();
        baseline = count;
        info("Mining " + count + " block(s).");
    }

    @Override
    public void onDeactivate() {
        if (client.gameMode != null) client.gameMode.stopDestroyBlock();
        releaseKeys();
        current = null;
        aiming = false;
    }

    // ---------------------------------------------------------------- selection (called by Overlay)

    public void onGlobalKey(int key, int modifiers) {
        if (client.player == null || client.level == null || client.screen != null) return;

        if (pos1Key.get().isSet() && pos1Key.get().matches(true, key, modifiers)) {
            BlockPos p = lookedAtBlock();
            if (p == null) return;
            corner1 = p;
            info("Corner 1: " + p.getX() + " " + p.getY() + " " + p.getZ() + sizeText());
        } else if (pos2Key.get().isSet() && pos2Key.get().matches(true, key, modifiers)) {
            BlockPos p = lookedAtBlock();
            if (p == null) return;
            corner2 = p;
            info("Corner 2: " + p.getX() + " " + p.getY() + " " + p.getZ() + sizeText());
        } else if (clearKey.get().isSet() && clearKey.get().matches(true, key, modifiers)) {
            corner1 = null;
            corner2 = null;
            info("Selection cleared.");
        }
    }

    private BlockPos lookedAtBlock() {
        HitResult hit = client.player.pick(selectRange.get(), 1.0F, false);
        if (hit.getType() != HitResult.Type.BLOCK) {
            warning("Look at a block first.");
            return null;
        }
        return ((BlockHitResult) hit).getBlockPos();
    }

    private String sizeText() {
        if (corner1 == null || corner2 == null) return "";
        int sx = Math.abs(corner1.getX() - corner2.getX()) + 1;
        int sy = Math.abs(corner1.getY() - corner2.getY()) + 1;
        int sz = Math.abs(corner1.getZ() - corner2.getZ()) + 1;
        return " (area " + sx + " x " + sy + " x " + sz + ")";
    }

    private long volume() {
        long sx = Math.abs(corner1.getX() - corner2.getX()) + 1L;
        long sy = Math.abs(corner1.getY() - corner2.getY()) + 1L;
        long sz = Math.abs(corner1.getZ() - corner2.getZ()) + 1L;
        return sx * sy * sz;
    }

    /** Draws the selected area (works even when the module is off). */
    public void renderSelection(Render3DEvent event) {
        if (!showBox.get() || corner1 == null || corner2 == null) return;

        double x1 = Math.min(corner1.getX(), corner2.getX()), x2 = Math.max(corner1.getX(), corner2.getX()) + 1.0;
        double y1 = Math.min(corner1.getY(), corner2.getY()), y2 = Math.max(corner1.getY(), corner2.getY()) + 1.0;
        double z1 = Math.min(corner1.getZ(), corner2.getZ()), z2 = Math.max(corner1.getZ(), corner2.getZ()) + 1.0;
        SettingColor c = boxColor.get();

        event.renderer.line(x1, y1, z1, x2, y1, z1, c);
        event.renderer.line(x2, y1, z1, x2, y1, z2, c);
        event.renderer.line(x2, y1, z2, x1, y1, z2, c);
        event.renderer.line(x1, y1, z2, x1, y1, z1, c);
        event.renderer.line(x1, y2, z1, x2, y2, z1, c);
        event.renderer.line(x2, y2, z1, x2, y2, z2, c);
        event.renderer.line(x2, y2, z2, x1, y2, z2, c);
        event.renderer.line(x1, y2, z2, x1, y2, z1, c);
        event.renderer.line(x1, y1, z1, x1, y2, z1, c);
        event.renderer.line(x2, y1, z1, x2, y2, z1, c);
        event.renderer.line(x2, y1, z2, x2, y2, z2, c);
        event.renderer.line(x1, y1, z2, x1, y2, z2, c);
    }

    // ---------------------------------------------------------------- targets

    private boolean mineable(BlockPos pos) {
        BlockState state = client.level.getBlockState(pos);
        if (state.isAir() || state.getBlock() instanceof LiquidBlock) return false;
        if (state.getDestroySpeed(client.level, pos) < 0) return false;   // bedrock and the like
        if (skipBlocks.get().contains(state.getBlock())) return false;
        return !skipped.contains(pos);
    }

    /** Lists every mineable block in the area in the chosen order. Returns how many there are. */
    private int rebuildTargets() {
        targets.clear();

        int minX = Math.min(corner1.getX(), corner2.getX()), maxX = Math.max(corner1.getX(), corner2.getX());
        int minY = Math.min(corner1.getY(), corner2.getY()), maxY = Math.max(corner1.getY(), corner2.getY());
        int minZ = Math.min(corner1.getZ(), corner2.getZ()), maxZ = Math.max(corner1.getZ(), corner2.getZ());

        for (int y = minY; y <= maxY; y++) {
            for (int x = minX; x <= maxX; x++) {
                for (int z = minZ; z <= maxZ; z++) {
                    BlockPos p = new BlockPos(x, y, z);
                    if (mineable(p)) targets.add(p);
                }
            }
        }

        final Vec3 eye = client.player.getEyePosition();
        final int low = minY;
        Comparator<BlockPos> byDistance = Comparator.comparingDouble(p -> eye.distanceToSqr(p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5));
        switch (order.get()) {
            case Nearest -> targets.sort(byDistance);
            case BottomUp -> targets.sort(Comparator.<BlockPos>comparingInt(BlockPos::getY).thenComparing(byDistance));
            case TopDown -> targets.sort(Comparator.<BlockPos>comparingInt(p -> -p.getY()).thenComparing(byDistance));
            case TwoLayersThenUp -> targets.sort(Comparator
                .<BlockPos>comparingInt(p -> p.getY() <= low + 1 ? 0 : 1)
                .thenComparingInt(BlockPos::getY)
                .thenComparing(byDistance));
        }
        lastScan = System.currentTimeMillis();
        return targets.size();
    }

    private double reachNow() {
        return client.player.getAttributeValue(Attributes.BLOCK_INTERACTION_RANGE) + reachExtra.get();
    }

    private boolean inReach(BlockPos pos, Vec3 eye, double reach) {
        return new AABB(pos).distanceToSqr(eye) <= reach * reach;
    }

    /** The next block to mine: the first one in the chosen order that is still there and within reach. */
    private BlockPos nextTarget(Vec3 eye, double reach) {
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        for (BlockPos p : targets) {
            if (!mineable(p) || !inReach(p, eye, reach)) continue;
            if (order.get() != Order.Nearest) return p;
            double d = eye.distanceToSqr(p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5);
            if (d < bestDist) {
                bestDist = d;
                best = p;
            }
        }
        return best;
    }

    private int remainingCount() {
        int n = 0;
        for (BlockPos p : targets) {
            if (mineable(p)) n++;
        }
        return n;
    }

    // ---------------------------------------------------------------- mining loop

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (client.player == null || client.level == null || client.gameMode == null) return;
        long now = System.currentTimeMillis();

        dropTick(now);
        if (dropPhase != 0) return;   // the drop (with the inventory screen) is in progress

        if (stage == Stage.WAIT_RESPAWN) {
            waitForRespawn(now);
            return;
        }
        if (client.screen != null) {   // not while an inventory or chest is open
            releaseKeys();
            return;
        }
        if (stage == Stage.WALKING) {
            walkTick(now);
            return;
        }

        if (stopWhenFull.get() && !hasFreeSlot()) {
            info("Your inventory is full, stopping.");
            toggle();
            return;
        }

        if (stopLowTool.get()) {
            ItemStack held = client.player.getMainHandItem();
            if (held.isDamageableItem() && held.getMaxDamage() - held.getDamageValue() <= 2) {
                warning("Your tool is almost broken, stopping.");
                toggle();
                return;
            }
        }

        Vec3 eye = client.player.getEyePosition();
        double reach = reachNow();
        int budget = mode.get() == Mode.Instant ? blocksPerTick.get() : 1;

        for (int done = 0; done < budget; ) {
            // Finished with the block we were working on?
            if (current != null && !mineable(current)) {
                client.gameMode.stopDestroyBlock();
                current = null;
            }

            if (current == null) {
                current = nextTarget(eye, reach);
                currentStart = now;
                if (current == null) {
                    int left = remainingCount();
                    if (left == 0) {
                        areaCleared();
                    } else if (reposition.get() && now >= walkBlockedUntil && startWalk(eye)) {
                        return;
                    } else if (now - lastReachMessage > 3000) {
                        lastReachMessage = now;
                        warning(left + " block(s) are out of your reach. Move closer.");
                    }
                    return;
                }
            }

            BlockState state = client.level.getBlockState(current);
            if (autoTool.get()) selectBestTool(state);
            aimAt(current);

            Direction face = Direction.getApproximateNearest(
                eye.x - (current.getX() + 0.5), eye.y - (current.getY() + 0.5), eye.z - (current.getZ() + 0.5));
            boolean instant = state.getDestroyProgress(client.player, client.level, current) >= 1.0F;

            if (mode.get() == Mode.Instant && instant) {
                client.gameMode.startDestroyBlock(current, face);
                client.player.swing(InteractionHand.MAIN_HAND);
                done++;
                current = null;   // the next block goes in the same tick (up to the budget)
                continue;
            }

            if (mode.get() == Mode.Instant && !fallbackNormal.get()) {
                skipped.add(current);
                current = null;
                continue;
            }

            // Normal way: hold the attack on this block until it breaks.
            if (now - currentStart > maxBlockTime.get()) {
                warning("Skipping a block that does not break.");
                client.gameMode.stopDestroyBlock();
                skipped.add(current);
                current = null;
                return;
            }
            if (now == currentStart || !client.gameMode.isDestroying()) {
                client.gameMode.startDestroyBlock(current, face);
            } else {
                client.gameMode.continueDestroyBlock(current, face);
            }
            client.player.swing(InteractionHand.MAIN_HAND);
            return;
        }
    }

    private boolean hasFreeSlot() {
        for (int i = 0; i < 36; i++) {
            if (client.player.getInventory().getItem(i).isEmpty()) return true;
        }
        return false;
    }

    /** Drops the chosen items once enough stacks of them are in the inventory. */
    private void dropTick(long now) {
        if (dropPhase == 1) {
            if (now < dropAt) return;
            for (int slot : dropSlots) InvUtils.drop().slot(slot);
            dropSlots.clear();
            dropPhase = 2;
            dropAt = now + 60;
            return;
        }
        if (dropPhase == 2) {
            if (now < dropAt) return;
            if (client.screen instanceof InventoryScreen) client.player.closeContainer();
            dropPhase = 0;
            return;
        }

        if (!autoDrop.get() || now - lastDropCheck < 500) return;
        lastDropCheck = now;
        if (client.screen != null || InvSession.busy() || dropItems.get().isEmpty()) return;

        dropSlots.clear();
        for (Item item : dropItems.get()) {
            int count = 0, max = new ItemStack(item).getMaxStackSize();
            List<Integer> slots = new ArrayList<>();
            for (int i = 0; i < 36; i++) {
                ItemStack s = client.player.getInventory().getItem(i);
                if (!s.is(item)) continue;
                count += s.getCount();
                slots.add(i);
            }
            if (count >= (long) dropStacks.get() * max) dropSlots.addAll(slots);
        }
        if (dropSlots.isEmpty()) return;

        if (dropOpenInventory.get()) {
            client.setScreen(new InventoryScreen(client.player));
            dropPhase = 1;
            dropAt = now + 50;
        } else {
            for (int slot : dropSlots) InvUtils.drop().slot(slot);
            dropSlots.clear();
        }
    }

    private void areaCleared() {
        cycles++;
        info("Area cleared (" + cycles + ").");
        if (!repeat.get() || (maxCycles.get() > 0 && cycles >= maxCycles.get())) {
            toggle();
            return;
        }
        skipped.clear();
        stage = Stage.WAIT_RESPAWN;
        lastScan = 0;
    }

    private void waitForRespawn(long now) {
        if (now - lastScan < 250) return;
        int count = rebuildTargets();
        baseline = Math.max(baseline, count);
        int needed = Math.max(1, (int) Math.ceil(baseline * respawnPercent.get() / 100.0));
        if (count >= needed) {
            info("The area respawned (" + count + " block(s)), mining again.");
            stage = Stage.MINING;
            current = null;
        }
    }

    private void selectBestTool(BlockState state) {
        int best = -1;
        float bestSpeed = 0f;
        for (int i = 0; i < 9; i++) {
            ItemStack s = client.player.getInventory().getItem(i);
            float speed = s.getDestroySpeed(state);
            if (speed > bestSpeed) {
                bestSpeed = speed;
                best = i;
            }
        }
        if (best < 0) return;
        if (client.player.getInventory().getItem(best) == client.player.getMainHandItem()) return;
        InvUtils.swap(best, false);
    }

    // ---------------------------------------------------------------- walking to a better spot

    /** Picks a place to stand from which more of the remaining blocks are reachable and starts walking there. */
    private boolean startWalk(Vec3 eye) {
        standSpot = findStandSpot(eye);
        if (standSpot == null) {
            walkBlockedUntil = System.currentTimeMillis() + 3000;
            return false;
        }
        if (walkFailures >= 3) {
            warning("Walking did not help three times in a row, stopping.");
            toggle();
            return true;
        }
        stage = Stage.WALKING;
        walkStart = System.currentTimeMillis();
        current = null;
        client.gameMode.stopDestroyBlock();
        return true;
    }

    private BlockPos findStandSpot(Vec3 eye) {
        BlockPos nearest = null;
        double nearestDist = Double.MAX_VALUE;
        List<BlockPos> remaining = new ArrayList<>();
        for (BlockPos p : targets) {
            if (!mineable(p)) continue;
            if (remaining.size() < 400) remaining.add(p);
            double d = eye.distanceToSqr(p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5);
            if (d < nearestDist) {
                nearestDist = d;
                nearest = p;
            }
        }
        if (nearest == null) return null;

        double reach = reachNow();
        int r = repositionRadius.get();
        BlockPos best = null;
        int bestScore = 0;
        double bestDist = Double.MAX_VALUE;
        double px = client.player.getX(), pz = client.player.getZ();

        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                for (int dy = -3; dy <= 1; dy++) {
                    BlockPos feet = nearest.offset(dx, dy, dz);
                    if (!standable(feet)) continue;
                    Vec3 e = new Vec3(feet.getX() + 0.5, feet.getY() + 1.62, feet.getZ() + 0.5);
                    int score = 0;
                    for (BlockPos q : remaining) {
                        if (inReach(q, e, reach)) score++;
                    }
                    if (score == 0) continue;
                    double dist = Math.hypot(feet.getX() + 0.5 - px, feet.getZ() + 0.5 - pz);
                    if (score > bestScore || (score == bestScore && dist < bestDist)) {
                        best = feet;
                        bestScore = score;
                        bestDist = dist;
                    }
                }
            }
        }
        return best;
    }

    /** A cell you can stand in: free feet and head space, solid floor, no liquid or fire. */
    private boolean standable(BlockPos feet) {
        BlockPos head = feet.above();
        BlockPos floor = feet.below();
        if (!client.level.getBlockState(feet).getCollisionShape(client.level, feet).isEmpty()) return false;
        if (!client.level.getBlockState(head).getCollisionShape(client.level, head).isEmpty()) return false;
        if (!client.level.getFluidState(feet).isEmpty() || !client.level.getFluidState(head).isEmpty()) return false;
        return client.level.getBlockState(floor).isFaceSturdy(client.level, floor, Direction.UP);
    }

    /** One step ahead is safe when it has ground within two blocks and no liquid. */
    private boolean safeStep(BlockPos feet) {
        if (!client.level.getFluidState(feet).isEmpty()) return false;
        for (int d = 1; d <= 2; d++) {
            BlockPos below = feet.below(d);
            if (client.level.getBlockState(below).isFaceSturdy(client.level, below, Direction.UP)) return true;
        }
        return false;
    }

    private void walkTick(long now) {
        double tx = standSpot.getX() + 0.5, tz = standSpot.getZ() + 0.5;
        double px = client.player.getX(), pz = client.player.getZ();
        double dx = tx - px, dz = tz - pz;
        double dist = Math.hypot(dx, dz);

        boolean arrived = dist < 0.3 && Math.abs(client.player.getY() - standSpot.getY()) < 1.5;
        if (arrived || now - walkStart > walkTimeout.get()) {
            releaseKeys();
            if (arrived) {
                walkFailures = 0;
            } else {
                walkFailures++;
                warning("Could not reach the spot in time.");
            }
            stage = Stage.MINING;
            current = null;
            return;
        }

        double nx = dx / Math.max(dist, 1.0e-6), nz = dz / Math.max(dist, 1.0e-6);
        BlockPos ahead = BlockPos.containing(px + nx * 0.9, client.player.getY(), pz + nz * 0.9);
        if (!safeStep(ahead)) {
            releaseKeys();
            walkFailures++;
            walkBlockedUntil = now + 3000;
            warning("It is not safe to walk on (a drop or liquid ahead), stopped.");
            stage = Stage.MINING;
            current = null;
            return;
        }

        float yaw = (float) Mth.wrapDegrees(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        startAim(yaw, 10.0f);
        client.options.keyUp.setDown(true);
        client.options.keyJump.setDown(client.player.horizontalCollision && client.player.onGround());
    }

    private void releaseKeys() {
        if (client.options == null) return;
        client.options.keyUp.setDown(false);
        client.options.keyJump.setDown(false);
    }

    // ---------------------------------------------------------------- camera

    private void aimAt(BlockPos pos) {
        if (!lookAtBlock.get()) return;
        Vec3 center = Vec3.atCenterOf(pos);
        startAim((float) Rotations.getYaw(center), Mth.clamp((float) Rotations.getPitch(center), -90f, 90f));
    }

    private void startAim(float yaw, float pitch) {
        if (aiming && Math.abs(Mth.wrapDegrees(yaw - aimYaw)) < 0.5f && Math.abs(pitch - aimPitch) < 0.5f) return;

        aimYaw = yaw;
        aimPitch = pitch;
        startYaw = client.player.getYRot();
        startPitch = client.player.getXRot();
        rotStart = System.currentTimeMillis();
        aiming = true;
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (!aiming || client.player == null) return;

        double duration = rotateTime.get();
        double t = duration > 0 ? Math.min(1.0, (System.currentTimeMillis() - rotStart) / duration) : 1.0;
        double e = t * t * (3.0 - 2.0 * t);

        float yaw = startYaw + Mth.wrapDegrees(aimYaw - startYaw) * (float) e;
        float pitch = Mth.clamp(startPitch + (aimPitch - startPitch) * (float) e, -90f, 90f);
        client.player.setYRot(yaw);
        client.player.setXRot(pitch);
        client.player.yRotO = yaw;
        client.player.xRotO = pitch;
    }
}
