package com.xbowcart.addon.modules;

import meteordevelopment.meteorclient.utils.player.InvUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.item.Item;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * One inventory visit, driven frame by frame: open the inventory screen, wait a moment (optionally
 * until you stand still), do the swaps one after another (the same hotbar-number swap you get by
 * hovering an item and pressing 1-9), check that every swap really happened (the server may undo
 * it) and redo the ones that did not, then close the screen.
 */
public class InvSession {
    /** Swap the slot {@code hotbar} (hotbar 0-8, or 40 = offhand) with the inventory slot {@code inv} (0-35). */
    public static class Op {
        public final int hotbar, inv;
        /** Item that must be in the hotbar slot after the swap. */
        public final Item expect;
        /** Item that was in the hotbar slot before the swap. */
        public final Item hotbarBefore;

        public Op(int hotbar, int inv, Item expect, Item hotbarBefore) {
            this.hotbar = hotbar;
            this.inv = inv;
            this.expect = expect;
            this.hotbarBefore = hotbarBefore;
        }
    }

    public boolean openScreen = true;
    public int waitBeforeClick = 40;
    public int clickDelay = 30;
    public int verifyWait = 80;
    public boolean waitUntilStill = false;

    /** Number of swaps that still did not work after the retries. */
    public int failed;

    private final Minecraft client = Minecraft.getInstance();
    private List<Op> ops = new ArrayList<>();
    private int phase, index, retries;
    private long t;
    private boolean running;

    /**
     * Sets the waits for one visit. Step mode uses the three given values. Total mode takes one
     * total time for the whole visit and splits it: 25% before the first click, 50% spread over the
     * clicks, 25% before the check.
     */
    public void timing(boolean totalMode, int totalMs, int wait, int click, int verify, int opCount) {
        if (totalMode) {
            waitBeforeClick = (int) (totalMs * 0.25);
            verifyWait = Math.max(20, (int) (totalMs * 0.25));
            clickDelay = opCount > 1 ? (int) (totalMs * 0.5 / (opCount - 1)) : 0;
        } else {
            waitBeforeClick = wait;
            clickDelay = click;
            verifyWait = verify;
        }
    }

    public boolean isRunning() {
        return running;
    }

    public void start(List<Op> list, long now) {
        ops = new ArrayList<>(list);
        phase = 0;
        index = 0;
        retries = 0;
        failed = 0;
        t = now;
        running = true;
    }

    public void abort() {
        if (running) closeScreen();
        running = false;
    }

    /** Call every frame. Returns true once the visit is completely finished (screen closed). */
    public boolean tick(long now) {
        if (!running) return true;
        if (client.player == null) {
            running = false;
            return true;
        }

        switch (phase) {
            case 0 -> {
                if (ops.isEmpty()) {
                    running = false;
                    return true;
                }
                if (openScreen) client.setScreen(new InventoryScreen(client.player));
                phase = 1;
                t = now;
                return false;
            }
            case 1 -> {
                boolean waited = now - t >= waitBeforeClick;
                boolean still = !waitUntilStill || isStill() || now - t > 1500;
                if (waited && still) {
                    phase = 2;
                    index = 0;
                    t = 0;
                }
                return false;
            }
            case 2 -> {
                if (index < ops.size() && now - t >= clickDelay) {
                    Op op = ops.get(index++);
                    if (op.inv < 9) InvUtils.quickSwap().fromId(op.hotbar).toHotbar(op.inv);
                    else InvUtils.quickSwap().fromId(op.hotbar).to(op.inv);
                    t = now;
                    if (index >= ops.size()) phase = 3;
                }
                return false;
            }
            case 3 -> {
                if (now - t < verifyWait) return false;
                List<Op> bad = new ArrayList<>();
                for (Op op : ops) {
                    if (client.player.getInventory().getItem(op.hotbar).getItem() != op.expect) bad.add(op);
                }
                if (bad.isEmpty()) {
                    phase = 4;
                } else if (retries < 2) {
                    retries++;
                    ops = bad;
                    index = 0;
                    phase = 2;
                    t = now;
                } else {
                    failed = bad.size();
                    phase = 4;
                }
                return false;
            }
            default -> {
                closeScreen();
                running = false;
                return true;
            }
        }
    }

    private boolean isStill() {
        Vec3 dm = client.player.getDeltaMovement();
        return Math.hypot(dm.x, dm.z) < 0.02;
    }

    private void closeScreen() {
        if (client.player != null && client.screen instanceof InventoryScreen) client.player.closeContainer();
    }
}
