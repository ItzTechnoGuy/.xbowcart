package com.xbowcart.addon.modules;

import meteordevelopment.meteorclient.utils.player.InvUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * One inventory visit, driven frame by frame: open the inventory screen, wait a moment (optionally
 * until you stand still), do the swaps one after another (the same hotbar-number swap you get by
 * hovering an item and pressing 1-9), check that every swap really happened (the server may undo
 * it) and redo the ones that did not, then close the screen.
 */
public class InvSession {
    /** Swap the slot {@code hotbar} (hotbar 0-8, or 40 = offhand) with the inventory slot {@code inv} (0-35). */
    public static class Op {
        /** Inventory index of the slot swapped with {@code inv}: hotbar 0-8, armor 36-39, offhand 40. */
        public final int hotbar, inv;
        /** Item that must be in that slot after the swap. */
        public final Item expect;
        /** Item that was in that slot before the swap. */
        public final Item hotbarBefore;
        /** Armor swaps compare the whole stack (enchantments count), not only the item type. */
        public final boolean armor;
        public final ItemStack expectStack, beforeStack;

        public Op(int hotbar, int inv, Item expect, Item hotbarBefore) {
            this(hotbar, inv, expect, hotbarBefore, false, null, null);
        }

        private Op(int hotbar, int inv, Item expect, Item hotbarBefore, boolean armor, ItemStack expectStack, ItemStack beforeStack) {
            this.hotbar = hotbar;
            this.inv = inv;
            this.expect = expect;
            this.hotbarBefore = hotbarBefore;
            this.armor = armor;
            this.expectStack = expectStack;
            this.beforeStack = beforeStack;
        }

        /** Swap armor slot {@code armorIndex} (0 boots, 1 leggings, 2 chestplate, 3 helmet) with inventory slot {@code inv}. */
        public static Op armor(int armorIndex, int inv, ItemStack expectStack, ItemStack beforeStack) {
            return new Op(36 + armorIndex, inv, expectStack.getItem(), beforeStack.getItem(), true, expectStack, beforeStack);
        }

        /** The swap that undoes this one. */
        public Op reversed() {
            if (armor) return new Op(hotbar, inv, hotbarBefore, expect, true, beforeStack, expectStack);
            return new Op(hotbar, inv, hotbarBefore, expect);
        }

        boolean matches(ItemStack actual) {
            if (armor && expectStack != null) return ItemStack.isSameItemSameComponents(actual, expectStack);
            return actual.getItem() == expect;
        }
    }

    public boolean openScreen = true;
    public int waitBeforeClick = 40;
    public int clickDelay = 30;
    public int verifyWait = 80;
    public boolean waitUntilStill = false;

    /** Number of swaps that still did not work after the retries. */
    public int failed;

    /** Only one inventory visit may run at a time (X-Bow Cart, Silent Totem and the refill key share this). */
    private static InvSession owner;

    private final Minecraft client = Minecraft.getInstance();
    private List<Op> ops = new ArrayList<>();
    private long lockWaitStart;
    private int phase, index, retries;
    private long t;
    private boolean running;

    /**
     * Sets the waits for one visit. Step mode uses the three given values. Total mode takes one
     * total time for the whole visit and splits it: 25% before the first click, 50% spread over the
     * clicks, 25% before the check.
     */
    public void timing(boolean totalMode, int totalMs, int wait, int click, int verify, int opCount) {
        if (totalMode) {
            waitBeforeClick = (int) (totalMs * 0.25);
            verifyWait = Math.max(20, (int) (totalMs * 0.25));
            clickDelay = opCount > 1 ? (int) (totalMs * 0.5 / (opCount - 1)) : 0;
        } else {
            waitBeforeClick = wait;
            clickDelay = click;
            verifyWait = verify;
        }
    }

    public boolean isRunning() {
        return running;
    }

    public void start(List<Op> list, long now) {
        ops = new ArrayList<>(list);
        phase = 0;
        index = 0;
        retries = 0;
        failed = 0;
        t = now;
        lockWaitStart = now;
        running = true;
        phase = -1;   // waiting for the inventory lock
    }

    public void abort() {
        if (running && phase >= 0) closeScreen();
        running = false;
        release();
    }

    private void release() {
        if (owner == this) owner = null;
    }

    /** Call every frame. Returns true once the visit is completely finished (screen closed). */
    public boolean tick(long now) {
        if (!running) return true;
        if (client.player == null) {
            running = false;
            release();
            return true;
        }

        if (phase == -1) {
            if (owner != null && owner != this && owner.running) {
                if (now - lockWaitStart > 3000) {
                    failed = ops.size();
                    running = false;
                    return true;
                }
                return false;
            }
            owner = this;
            phase = 0;
            t = now;
        }

        switch (phase) {
            case 0 -> {
                if (ops.isEmpty()) {
                    running = false;
                    release();
                    return true;
                }
                if (openScreen) client.setScreen(new InventoryScreen(client.player));
                phase = 1;
                t = now;
                return false;
            }
            case 1 -> {
                boolean waited = now - t >= waitBeforeClick;
                boolean still = !waitUntilStill || isStill() || now - t > 1500;
                if (waited && still) {
                    phase = 2;
                    index = 0;
                    t = 0;
                }
                return false;
            }
            case 2 -> {
                if (index < ops.size() && now - t >= clickDelay) {
                    Op op = ops.get(index++);
                    if (op.armor) InvUtils.move().from(op.inv).toArmor(op.hotbar - 36);
                    else if (op.inv < 9) InvUtils.quickSwap().fromId(op.hotbar).toHotbar(op.inv);
                    else InvUtils.quickSwap().fromId(op.hotbar).to(op.inv);
                    t = now;
                    if (index >= ops.size()) phase = 3;
                }
                return false;
            }
            case 3 -> {
                if (now - t < verifyWait) return false;
                List<Op> bad = new ArrayList<>();
                for (Op op : ops) {
                    if (!op.matches(slotStack(op))) bad.add(op);
                }
                if (bad.isEmpty()) {
                    phase = 4;
                } else if (retries < 2) {
                    retries++;
                    ops = bad;
                    index = 0;
                    phase = 2;
                    t = now;
                } else {
                    failed = bad.size();
                    phase = 4;
                }
                return false;
            }
            default -> {
                closeScreen();
                running = false;
                release();
                return true;
            }
        }
    }

    /** What is in the slot of this swap right now (armor and offhand are read the safe way). */
    private ItemStack slotStack(Op op) {
        if (op.armor) return client.player.getItemBySlot(EquipmentSlot.LEGS);
        if (op.hotbar == 40) return client.player.getOffhandItem();
        return client.player.getInventory().getItem(op.hotbar);
    }

    private boolean isStill() {
        Vec3 dm = client.player.getDeltaMovement();
        return Math.hypot(dm.x, dm.z) < 0.02;
    }

    private void closeScreen() {
        if (client.player != null && client.screen instanceof InventoryScreen) client.player.closeContainer();
    }
}
