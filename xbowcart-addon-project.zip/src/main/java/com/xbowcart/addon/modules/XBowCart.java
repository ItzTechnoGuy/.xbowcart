package com.xbowcart.addon.modules;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.function.Predicate;

/**
 * X-Bow Cart 1.2 by ItzTechnoGuy.
 *
 * Line (you -> [slab] -> fire -> TNT minecart). The module simulates the crossbow arrow physics
 * (speed 3.15, drag 0.99, gravity 0.05 per tick) to pick the aim angle, and it never refuses to
 * fire: if the simulation thinks the shot might fail it only prints a warning and shoots anyway.
 * Nothing waits for game ticks; every step is sent as soon as its own delay has passed.
 */
public class XBowCart extends Module {
    private enum Step { RAIL, CART, FIRE, SLAB, SHOOT }

    private enum Stage { IDLE, ROTATING, RECHARGE, TRACK }

    private static final double ARROW_SPEED = 3.15;
    private static final double DRAG = 0.99;
    private static final double GRAVITY = 0.05;
    private static final double ARROW_HALF = 0.25;
    private static final double[] FRACS = {0.4, 0.25, 0.55, 0.7, 0.15};
    private static final int EQUIP_FAIL = -2;
    private static final int EQUIP_OK_UNKNOWN_SLOT = -1;

    private static class Solution {
        boolean ok;
        float yaw, pitch;
        String reason = "";
    }

    private final Minecraft client = Minecraft.getInstance();

    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Integer> stepDelay = sg.add(new IntSetting.Builder()
        .name("step-delay")
        .description("Minimum time between two steps, in ms. 0 = send everything as fast as the frame rate allows.")
        .defaultValue(20)
        .range(0, 500)
        .sliderRange(0, 200)
        .build());

    private final Setting<Boolean> smoothRotation = sg.add(new BoolSetting.Builder()
        .name("smooth-rotation")
        .description("Move the camera smoothly to each target instead of snapping.")
        .defaultValue(true)
        .build());

    private final Setting<Integer> rotateTime = sg.add(new IntSetting.Builder()
        .name("rotate-time")
        .description("Camera movement time per step, in ms (runs together with the step delay).")
        .defaultValue(20)
        .range(0, 300)
        .sliderRange(0, 200)
        .visible(smoothRotation::get)
        .build());

    private final Setting<Double> range = sg.add(new DoubleSetting.Builder()
        .name("range")
        .description("How far away the block under the crosshair can be. The server limits block reach to roughly 4.5 blocks.")
        .defaultValue(5.0)
        .range(2.0, 6.0)
        .sliderRange(2.0, 6.0)
        .decimalPlaces(1)
        .build());

    private final Setting<Boolean> safeMode = sg.add(new BoolSetting.Builder()
        .name("safe-mode")
        .description("Places an oak or cherry slab between you and the fire. If there is no room for it, the module just continues without it.")
        .defaultValue(true)
        .build());

    private final Setting<Double> igniteHeight = sg.add(new DoubleSetting.Builder()
        .name("ignite-height")
        .description("Height of the fire cell in which a passing arrow gets lit (1.0 = the whole block).")
        .defaultValue(1.0)
        .range(0.1, 1.0)
        .sliderRange(0.1, 1.0)
        .decimalPlaces(2)
        .build());

    private final Setting<Boolean> autoRecharge = sg.add(new BoolSetting.Builder()
        .name("auto-recharge")
        .description("After shooting, hold use until the crossbow is charged again (needs arrows or fireworks).")
        .defaultValue(true)
        .build());

    private final Setting<Integer> scratchSlot = sg.add(new IntSetting.Builder()
        .name("scratch-hotbar-slot")
        .description("Hotbar slot (1-9) used when an item has to be pulled from the main inventory.")
        .defaultValue(9)
        .range(1, 9)
        .sliderRange(1, 9)
        .build());

    private final Setting<Boolean> debugMode = sg.add(new BoolSetting.Builder()
        .name("debug")
        .description("Print what the solver chose and whether the arrow was lit and the cart exploded.")
        .defaultValue(false)
        .build());

    private final ArrayDeque<Step> queue = new ArrayDeque<>();
    private final Set<Integer> arrowsBefore = new HashSet<>();

    private Stage stage = Stage.IDLE;
    private Step current;
    private BlockPos railPos, firePos, slabPos;
    private AABB estimatedCart;
    private long phaseStart, lastAction, rechargeStart, trackUntil;
    private float startYaw, startPitch, targetYaw, targetPitch;
    private boolean rechargeBegan, holdingUse;
    private boolean arrowSeen, arrowLit;
    private Entity cartRef;

    public XBowCart() {
        super(Categories.Combat, "x-bow-cart", "Places a rail, TNT minecart and fire at the crosshair block, then shoots the cart with a crossbow. By ItzTechnoGuy.");
        keybind.set(true, GLFW.GLFW_KEY_B, 0);
    }

    @Override
    public void onActivate() {
        queue.clear();
        arrowsBefore.clear();
        current = null;
        cartRef = null;
        stage = Stage.IDLE;
        rechargeBegan = false;
        holdingUse = false;
        arrowSeen = false;
        arrowLit = false;
        trackUntil = 0;
        lastAction = 0;

        if (!prepare()) {
            toggle();
            return;
        }
        startStep();
    }

    @Override
    public void onDeactivate() {
        releaseUse();
        stage = Stage.IDLE;
        queue.clear();
    }

    // ---------------------------------------------------------------- preparation

    private boolean prepare() {
        if (client.player == null || client.level == null) return false;

        HitResult hit = client.player.pick(range.get(), 1.0F, false);
        if (hit.getType() != HitResult.Type.BLOCK) {
            error("Look at a block first.");
            return false;
        }
        BlockHitResult blockHit = (BlockHitResult) hit;
        railPos = blockHit.getBlockPos().relative(blockHit.getDirection());

        if (!canPlaceAt(railPos)) {
            error("Can't place a rail there (needs free space on solid ground).");
            return false;
        }

        estimatedCart = new AABB(railPos.getX() + 0.01, railPos.getY() + 0.0625, railPos.getZ() + 0.01,
            railPos.getX() + 0.99, railPos.getY() + 0.7625, railPos.getZ() + 0.99);
        Vec3 cc = estimatedCart.getCenter();

        // Horizontal direction from the cart toward you.
        double ux = client.player.getX() - cc.x;
        double uz = client.player.getZ() - cc.z;
        double len = Math.hypot(ux, uz);
        if (len < 0.3) {
            ux = 1;
            uz = 0;
        } else {
            ux /= len;
            uz /= len;
        }

        Vec3 origin = arrowOrigin();
        BlockPos playerCell = client.player.blockPosition();
        BlockPos bestFire = null, bestSlab = null;
        Solution bestSol = null;
        String lastReason = "no free cell with solid ground";

        for (int k = 1; k <= 3; k++) {
            BlockPos f = findPlaceable(cc.x + ux * k, cc.z + uz * k, railPos.getY());
            if (f == null || f.equals(railPos) || f.equals(playerCell)) continue;

            BlockPos s = null;
            if (safeMode.get()) {
                s = findPlaceable(cc.x + ux * (k + 1), cc.z + uz * (k + 1), railPos.getY());
                if (s != null && (s.equals(f) || s.equals(railPos) || s.equals(playerCell))) s = null;
            }

            Solution sol = solveBest(origin, estimatedCart, f, s);
            if (bestSol == null) {
                bestFire = f;
                bestSlab = s;
                bestSol = sol;
            }
            if (sol.ok) {
                bestFire = f;
                bestSlab = s;
                bestSol = sol;
                break;
            }
            lastReason = sol.reason;
        }

        if (bestFire == null) {
            error("No place for the fire next to the cart: " + lastReason + ".");
            return false;
        }

        firePos = bestFire;
        slabPos = bestSlab;
        if (safeMode.get() && slabPos == null) warning("No room for the slab, continuing without it.");
        if (!bestSol.ok) warning("The shot might not work (" + bestSol.reason + "). Shooting anyway.");
        debugInfo("Fire at " + firePos.toShortString() + ", pitch " + Math.round(bestSol.pitch * 10) / 10.0);

        queue.add(Step.RAIL);
        queue.add(Step.CART);
        queue.add(Step.FIRE);
        if (slabPos != null) queue.add(Step.SLAB);
        queue.add(Step.SHOOT);

        for (Step step : queue) {
            if (!InvUtils.find(predicateFor(step)).found()) {
                error("Missing item for step: " + describe(step));
                queue.clear();
                return false;
            }
        }
        return true;
    }

    /** Finds a free cell with solid ground in this column, at the base height or one block lower/higher. */
    private BlockPos findPlaceable(double x, double z, int baseY) {
        int[] offsets = {0, -1, 1};
        for (int dy : offsets) {
            BlockPos p = BlockPos.containing(x, baseY + dy, z);
            if (canPlaceAt(p)) return p;
        }
        return null;
    }

    private boolean canPlaceAt(BlockPos pos) {
        BlockState state = client.level.getBlockState(pos);
        if (!state.canBeReplaced()) return false;
        BlockPos below = pos.below();
        return client.level.getBlockState(below).isFaceSturdy(client.level, below, Direction.UP);
    }

    private String describe(Step step) {
        return switch (step) {
            case RAIL -> "rail";
            case CART -> "TNT minecart";
            case FIRE -> "flint and steel";
            case SLAB -> "oak/cherry slab";
            case SHOOT -> "charged crossbow";
        };
    }

    private Predicate<ItemStack> predicateFor(Step step) {
        return switch (step) {
            case RAIL -> s -> s.is(Items.RAIL) || s.is(Items.POWERED_RAIL);
            case CART -> s -> s.is(Items.TNT_MINECART);
            case FIRE -> s -> s.is(Items.FLINT_AND_STEEL);
            case SLAB -> s -> s.is(Items.OAK_SLAB) || s.is(Items.CHERRY_SLAB);
            case SHOOT -> s -> s.is(Items.CROSSBOW) && CrossbowItem.isCharged(s);
        };
    }

    private Vec3 aimPoint(Step step) {
        return switch (step) {
            case RAIL -> Vec3.atBottomCenterOf(railPos);
            case CART -> Vec3.atBottomCenterOf(railPos).add(0, 0.1, 0);
            case FIRE -> Vec3.atBottomCenterOf(firePos);
            case SLAB -> Vec3.atBottomCenterOf(slabPos);
            case SHOOT -> Vec3.atBottomCenterOf(railPos).add(0, 0.4, 0);
        };
    }

    // ---------------------------------------------------------------- arrow physics

    /** Where the arrow spawns: your position at eye height minus 0.1. */
    private Vec3 arrowOrigin() {
        return new Vec3(client.player.getX(), client.player.getEyeY() - 0.1, client.player.getZ());
    }

    /** Always returns an aim. {@code ok} tells whether the simulation thinks the shot works. */
    private Solution solveBest(Vec3 origin, AABB cartBox, BlockPos fire, BlockPos slab) {
        Solution first = null;
        for (double frac : FRACS) {
            Solution s = solve(origin, cartBox, fire, slab, frac);
            if (s.ok) return s;
            if (first == null) first = s;
        }
        return first;
    }

    private Solution solve(Vec3 origin, AABB cartBox, BlockPos fire, BlockPos slab, double frac) {
        Vec3 c = cartBox.getCenter();
        double targetY = cartBox.minY + frac * (cartBox.maxY - cartBox.minY);
        double dx = c.x - origin.x;
        double dz = c.z - origin.z;
        double dist = Math.hypot(dx, dz);

        Solution s = new Solution();
        s.yaw = (float) Mth.wrapDegrees(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);

        if (dist < 0.5) {
            // Practically on top of the cart: no physics, aim straight at it.
            s.pitch = (float) -Math.toDegrees(Math.atan2(targetY - origin.y, Math.max(dist, 0.01)));
            s.ok = false;
            s.reason = "too close to the cart";
            return s;
        }

        // Bisection on pitch (positive = down): higher pitch -> arrow lands lower.
        double lo = -45.0, hi = 70.0;
        for (int i = 0; i < 40; i++) {
            double mid = (lo + hi) / 2.0;
            if (heightAt(origin, s.yaw, mid, dist) > targetY) lo = mid;
            else hi = mid;
        }
        s.pitch = (float) ((lo + hi) / 2.0);

        String problem = checkPath(origin, s.yaw, s.pitch, cartBox, fire, slab);
        s.ok = problem == null;
        s.reason = problem == null ? "" : problem;
        return s;
    }

    /** Height of the arrow when it has travelled {@code dist} blocks horizontally. */
    private double heightAt(Vec3 origin, float yawDeg, double pitchDeg, double dist) {
        double yr = Math.toRadians(yawDeg), pr = Math.toRadians(pitchDeg);
        double vx = -Math.sin(yr) * Math.cos(pr) * ARROW_SPEED;
        double vy = -Math.sin(pr) * ARROW_SPEED;
        double vz = Math.cos(yr) * Math.cos(pr) * ARROW_SPEED;
        double y = origin.y, h = 0;
        for (int i = 0; i < 100; i++) {
            double hv = Math.hypot(vx, vz);
            if (hv < 1.0e-6) return -1000;
            if (h + hv >= dist) return y + vy * ((dist - h) / hv);
            h += hv;
            y += vy;
            vx *= DRAG;
            vz *= DRAG;
            vy = vy * DRAG - GRAVITY;
        }
        return -1000;
    }

    /** Returns null if the arrow is lit by the fire and then hits the cart; otherwise the reason it fails. */
    private String checkPath(Vec3 origin, float yawDeg, float pitchDeg, AABB cartBox, BlockPos fire, BlockPos slab) {
        double yr = Math.toRadians(yawDeg), pr = Math.toRadians(pitchDeg);
        Vec3 p = origin;
        Vec3 v = new Vec3(-Math.sin(yr) * Math.cos(pr) * ARROW_SPEED, -Math.sin(pr) * ARROW_SPEED, Math.cos(yr) * Math.cos(pr) * ARROW_SPEED);

        // The arrow is a 0.5 x 0.5 box, so every target box is grown by half of that.
        AABB fireBox = new AABB(fire.getX(), fire.getY(), fire.getZ(), fire.getX() + 1, fire.getY() + igniteHeight.get(), fire.getZ() + 1)
            .inflate(ARROW_HALF);
        AABB slabBox = slab == null ? null
            : new AABB(slab.getX(), slab.getY(), slab.getZ(), slab.getX() + 1, slab.getY() + 0.5, slab.getZ() + 1).inflate(ARROW_HALF);
        AABB cartHit = cartBox.inflate(ARROW_HALF);
        boolean lit = false;

        for (int t = 0; t < 100; t++) {
            Vec3 n = p.add(v);

            double cartD = entryDist(cartHit, p, n);
            double fireD = entryDist(fireBox, p, n);
            if (fireD >= 0 && (cartD < 0 || fireD <= cartD)) lit = true;

            if (slabBox != null) {
                double slabD = entryDist(slabBox, p, n);
                if (slabD >= 0 && (cartD < 0 || slabD < cartD)) return "the arrow would hit the slab";
            }

            BlockHitResult bh = client.level.clip(new ClipContext(p, n, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, client.player));
            if (bh.getType() == HitResult.Type.BLOCK) {
                double bd = p.distanceToSqr(bh.getLocation());
                if (cartD < 0 || bd < cartD) return "the arrow would hit a block at " + bh.getBlockPos().toShortString();
            }

            if (cartD >= 0) return lit ? null : "the arrow reaches the cart without passing through the fire";

            p = n;
            v = new Vec3(v.x * DRAG, v.y * DRAG - GRAVITY, v.z * DRAG);
        }
        return "the arrow never reaches the cart";
    }

    /** Squared distance from {@code a} to where the segment a->b enters the box, or -1 if it doesn't. */
    private double entryDist(AABB box, Vec3 a, Vec3 b) {
        if (box.contains(a)) return 0;
        Optional<Vec3> hit = box.clip(a, b);
        return hit.isPresent() ? a.distanceToSqr(hit.get()) : -1;
    }

    // ---------------------------------------------------------------- step machine

    private void startStep() {
        if (client.player == null || client.level == null) {
            toggle();
            return;
        }

        current = queue.poll();
        if (current == null) {
            beginPost();
            return;
        }

        if (equip(predicateFor(current)) == EQUIP_FAIL) {
            error("Missing item for step: " + describe(current));
            toggle();
            return;
        }

        if (current == Step.SHOOT) {
            Solution sol = solveBest(arrowOrigin(), estimatedCart, firePos, slabPos);
            targetYaw = sol.yaw;
            targetPitch = sol.pitch;
        } else {
            Vec3 aim = aimPoint(current);
            targetYaw = (float) Rotations.getYaw(aim);
            targetPitch = Mth.clamp((float) Rotations.getPitch(aim), -90f, 90f);
        }

        startYaw = client.player.getYRot();
        startPitch = client.player.getXRot();
        phaseStart = System.currentTimeMillis();
        stage = Stage.ROTATING;
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (stage == Stage.IDLE) return;
        if (client.player == null || client.level == null) {
            toggle();
            return;
        }

        trackArrows(System.currentTimeMillis());

        // Several steps can run in one frame, so nothing is limited by game ticks.
        for (int guard = 0; guard < 12; guard++) {
            if (!advance(System.currentTimeMillis())) break;
        }
    }

    /** Returns true if the stage changed and another transition may be possible right away. */
    private boolean advance(long now) {
        switch (stage) {
            case ROTATING -> {
                double duration = rotateTime.get();
                double t = (smoothRotation.get() && duration > 0)
                    ? Math.min(1.0, (now - phaseStart) / duration) : 1.0;
                double e = t * t * (3.0 - 2.0 * t);

                float dYaw = Mth.wrapDegrees(targetYaw - startYaw);
                setCamera(startYaw + dYaw * (float) e, startPitch + (targetPitch - startPitch) * (float) e);

                if (t >= 1.0 && now - lastAction >= stepDelay.get()) {
                    performAction(now);
                    lastAction = System.currentTimeMillis();
                    startStep();
                    return true;
                }
                return false;
            }
            case RECHARGE -> {
                recharge(now);
                return false;
            }
            case TRACK -> {
                if (now >= trackUntil) {
                    reportTrack();
                    toggle();
                }
                return false;
            }
            default -> {
                return false;
            }
        }
    }

    private void performAction(long now) {
        switch (current) {
            case RAIL -> clickBlock(railPos.below());
            case CART -> clickBlock(railPos);
            case FIRE -> clickBlock(firePos.below());
            case SLAB -> clickBlock(slabPos.below());
            case SHOOT -> shoot(now);
        }
    }

    private void shoot(long now) {
        // Fresh aim from where you are right now (so walking works). Always fires.
        Entity cart = findCart();
        cartRef = cart;
        AABB box = cart != null ? cart.getBoundingBox() : estimatedCart;
        Solution sol = solveBest(arrowOrigin(), box, firePos, slabPos);
        if (!sol.ok) warning("The shot might not work (" + sol.reason + "). Shooting anyway.");

        setCamera(sol.yaw, sol.pitch);
        sendRotation(sol.yaw, sol.pitch);

        snapshotArrows();
        trackUntil = now + 2500;

        client.gameMode.useItem(client.player, InteractionHand.MAIN_HAND);
        client.player.swing(InteractionHand.MAIN_HAND);
        debugInfo("Shot fired.");
    }

    /** Tells the server the new look direction right away, instead of waiting for the next game tick. */
    private void sendRotation(float yaw, float pitch) {
        if (client.getConnection() == null) return;
        client.getConnection().send(new ServerboundMovePlayerPacket.Rot(yaw, pitch, client.player.onGround(), client.player.horizontalCollision));
    }

    private void clickBlock(BlockPos support) {
        Vec3 hitVec = Vec3.atBottomCenterOf(support.above());
        BlockHitResult result = new BlockHitResult(hitVec, Direction.UP, support, false);
        client.gameMode.useItemOn(client.player, InteractionHand.MAIN_HAND, result);
        client.player.swing(InteractionHand.MAIN_HAND);
    }

    private Entity findCart() {
        AABB area = new AABB(railPos.getX() - 1.5, railPos.getY() - 1.0, railPos.getZ() - 1.5,
            railPos.getX() + 2.5, railPos.getY() + 2.0, railPos.getZ() + 2.5);
        for (Entity e : client.level.getEntities((Entity) null, area, x -> x.getType() == EntityType.TNT_MINECART)) {
            return e;
        }
        return null;
    }

    // ---------------------------------------------------------------- after the shot

    private void beginPost() {
        if (autoRecharge.get()) {
            stage = Stage.RECHARGE;
            rechargeBegan = false;
            return;
        }
        finish();
    }

    private void finish() {
        if (debugMode.get() && System.currentTimeMillis() < trackUntil) {
            stage = Stage.TRACK;
        } else {
            toggle();
        }
    }

    private void recharge(long now) {
        if (!rechargeBegan) {
            if (equip(s -> s.is(Items.CROSSBOW)) == EQUIP_FAIL) {
                warning("No crossbow to recharge.");
                finish();
                return;
            }
            client.options.keyUse.setDown(true);
            holdingUse = true;
            rechargeBegan = true;
            rechargeStart = now;
            return;
        }

        ItemStack held = client.player.getMainHandItem();
        boolean charged = held.is(Items.CROSSBOW) && CrossbowItem.isCharged(held);
        if (charged || !held.is(Items.CROSSBOW) || now - rechargeStart > 5000) {
            releaseUse();
            if (!charged) warning("Crossbow did not recharge (no arrows or fireworks?).");
            finish();
        }
    }

    private void releaseUse() {
        if (holdingUse && client.options != null) {
            client.options.keyUse.setDown(false);
        }
        holdingUse = false;
    }

    // ---------------------------------------------------------------- debug tracking

    private void snapshotArrows() {
        arrowsBefore.clear();
        arrowSeen = false;
        arrowLit = false;
        for (Entity e : client.level.entitiesForRendering()) {
            if (e.getType() == EntityType.ARROW) arrowsBefore.add(e.getId());
        }
    }

    private void trackArrows(long now) {
        if (!debugMode.get() || now >= trackUntil || client.level == null) return;
        for (Entity e : client.level.entitiesForRendering()) {
            if (e.getType() == EntityType.ARROW && !arrowsBefore.contains(e.getId())) {
                arrowSeen = true;
                if (e.isOnFire()) arrowLit = true;
            }
        }
    }

    private void reportTrack() {
        if (!debugMode.get()) return;
        String cart = cartRef == null ? "unknown" : (cartRef.isRemoved() ? "destroyed (exploded)" : "still there");
        info("Arrow seen: " + arrowSeen + ", lit: " + arrowLit + ", minecart: " + cart + ".");
    }

    private void debugInfo(String message) {
        if (debugMode.get()) info(message);
    }

    // ---------------------------------------------------------------- helpers

    private void setCamera(float yaw, float pitch) {
        float p = Mth.clamp(pitch, -90f, 90f);
        client.player.setYRot(yaw);
        client.player.setXRot(p);
        client.player.yRotO = yaw;
        client.player.xRotO = p;
    }

    /**
     * Puts a matching item in the main hand, pulling it into the scratch hotbar slot if needed.
     * Returns the hotbar slot used, EQUIP_OK_UNKNOWN_SLOT if it was already in hand, or EQUIP_FAIL.
     */
    private int equip(Predicate<ItemStack> predicate) {
        ItemStack held = client.player.getMainHandItem();
        if (predicate.test(held)) {
            for (int i = 0; i < 9; i++) {
                if (client.player.getInventory().getItem(i) == held) return i;
            }
            return EQUIP_OK_UNKNOWN_SLOT;
        }

        FindItemResult result = InvUtils.find(predicate);
        if (!result.found()) return EQUIP_FAIL;

        if (result.isHotbar()) {
            InvUtils.swap(result.slot(), false);
            return result.slot();
        }
        if (result.isMain()) {
            int scratch = scratchSlot.get() - 1;
            InvUtils.quickSwap().fromId(scratch).to(result.slot());
            InvUtils.swap(scratch, false);
            return scratch;
        }
        return EQUIP_FAIL;
    }
}
