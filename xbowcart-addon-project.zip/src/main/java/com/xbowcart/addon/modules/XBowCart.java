package com.xbowcart.addon.modules;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.function.Predicate;

/**
 * X-Bow Cart 1.1.
 *
 * Line (you -> [slab] -> fire -> TNT minecart). The module simulates the real crossbow arrow
 * physics (speed 3.15, drag 0.99, gravity 0.05 per tick) and only fires from an angle where the
 * arrow flies through the fire cell first and then hits the minecart, without touching the slab
 * or any block. It uses the minecart's real position and your real position at the moment of
 * the shot, so it also works while walking (as long as the shot is still valid).
 */
public class XBowCart extends Module {
    private enum Step { RAIL, CART, FIRE, SLAB, SHOOT }

    private enum Stage { IDLE, ROTATING, WAITING, CART_WAIT, RESTOCK, RECHARGE, TRACK }

    private static final double ARROW_SPEED = 3.15;
    private static final double DRAG = 0.99;
    private static final double GRAVITY = 0.05;
    private static final double[] FRACS = {0.5, 0.35, 0.65, 0.2, 0.8};
    private static final int EQUIP_FAIL = -2;
    private static final int EQUIP_OK_UNKNOWN_SLOT = -1;

    private static class Solution {
        boolean ok;
        float yaw, pitch;
        String reason = "";

        static Solution fail(String reason) {
            Solution s = new Solution();
            s.reason = reason;
            return s;
        }
    }

    private final Minecraft client = Minecraft.getInstance();

    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Double> speed = sg.add(new DoubleSetting.Builder()
        .name("speed")
        .description("Overall speed. 1.0 = normal, lower = slower (down to 0.1), higher = faster (up to 10).")
        .defaultValue(1.0)
        .range(0.1, 10.0)
        .sliderRange(0.1, 10.0)
        .decimalPlaces(1)
        .build());

    private final Setting<Integer> baseDelay = sg.add(new IntSetting.Builder()
        .name("base-delay")
        .description("Delay in ms after each step at speed 1.0 (real delay = this / speed).")
        .defaultValue(100)
        .range(0, 1000)
        .sliderRange(0, 500)
        .build());

    private final Setting<Boolean> smoothRotation = sg.add(new BoolSetting.Builder()
        .name("smooth-rotation")
        .description("Move the camera smoothly to each target instead of snapping.")
        .defaultValue(true)
        .build());

    private final Setting<Integer> rotateTime = sg.add(new IntSetting.Builder()
        .name("rotate-time")
        .description("Camera movement time in ms per step at speed 1.0 (real time = this / speed).")
        .defaultValue(80)
        .range(0, 500)
        .sliderRange(0, 300)
        .visible(smoothRotation::get)
        .build());

    private final Setting<Double> range = sg.add(new DoubleSetting.Builder()
        .name("range")
        .description("How far away the block under the crosshair can be. The server limits block reach to roughly 4.5 blocks.")
        .defaultValue(5.0)
        .range(2.0, 6.0)
        .sliderRange(2.0, 6.0)
        .decimalPlaces(1)
        .build());

    private final Setting<Boolean> safeMode = sg.add(new BoolSetting.Builder()
        .name("safe-mode")
        .description("Places an oak or cherry slab between you and the fire so the blast hits the slab instead of your legs.")
        .defaultValue(true)
        .build());

    private final Setting<Double> igniteHeight = sg.add(new DoubleSetting.Builder()
        .name("ignite-height")
        .description("How high above the ground the arrow must pass through the fire cell to be lit. Lower = stricter (arrow must fly lower).")
        .defaultValue(0.6)
        .range(0.1, 1.0)
        .sliderRange(0.1, 1.0)
        .decimalPlaces(2)
        .build());

    private final Setting<Boolean> restock = sg.add(new BoolSetting.Builder()
        .name("restock-tnt-minecart")
        .description("After shooting, put a TNT minecart from your inventory back into the hotbar slot the used one came from.")
        .defaultValue(false)
        .build());

    private final Setting<Boolean> openInventory = sg.add(new BoolSetting.Builder()
        .name("open-inventory")
        .description("Open the inventory screen while restocking.")
        .defaultValue(true)
        .visible(restock::get)
        .build());

    private final Setting<Boolean> autoRecharge = sg.add(new BoolSetting.Builder()
        .name("auto-recharge")
        .description("After shooting (and restocking), hold use until the crossbow is charged again (needs arrows or fireworks).")
        .defaultValue(true)
        .build());

    private final Setting<Integer> scratchSlot = sg.add(new IntSetting.Builder()
        .name("scratch-hotbar-slot")
        .description("Hotbar slot (1-9) used when an item has to be pulled from the main inventory.")
        .defaultValue(9)
        .range(1, 9)
        .sliderRange(1, 9)
        .build());

    private final Setting<Boolean> debugMode = sg.add(new BoolSetting.Builder()
        .name("debug")
        .description("Print what the solver chose and whether the arrow was lit and the cart exploded.")
        .defaultValue(false)
        .build());

    private final ArrayDeque<Step> queue = new ArrayDeque<>();
    private final ArrayDeque<Stage> post = new ArrayDeque<>();
    private final Set<Integer> arrowsBefore = new HashSet<>();

    private Stage stage = Stage.IDLE;
    private Step current;
    private BlockPos railPos, firePos, slabPos;
    private AABB estimatedCart;
    private Entity cartRef;
    private int cartSlot = EQUIP_OK_UNKNOWN_SLOT;
    private long phaseStart, scheduledAt, rechargeStart, trackUntil;
    private float startYaw, startPitch, targetYaw, targetPitch;
    private boolean actionDone, rechargeBegan, holdingUse, postBuilt;
    private int restockPhase, restockSlot;
    private boolean arrowSeen, arrowLit;

    public XBowCart() {
        super(Categories.Combat, "x-bow-cart", "Places a rail, TNT minecart and fire at the crosshair block, then shoots the cart with a crossbow.");
        keybind.set(true, GLFW.GLFW_KEY_B, 0);
    }

    @Override
    public void onActivate() {
        queue.clear();
        post.clear();
        arrowsBefore.clear();
        current = null;
        cartRef = null;
        cartSlot = EQUIP_OK_UNKNOWN_SLOT;
        stage = Stage.IDLE;
        actionDone = false;
        rechargeBegan = false;
        holdingUse = false;
        postBuilt = false;
        restockPhase = 0;
        arrowSeen = false;
        arrowLit = false;
        trackUntil = 0;

        if (!prepare()) {
            toggle();
            return;
        }
        startStep();
    }

    @Override
    public void onDeactivate() {
        releaseUse();
        stage = Stage.IDLE;
        queue.clear();
        post.clear();
    }

    // ---------------------------------------------------------------- preparation

    private boolean prepare() {
        if (client.player == null || client.level == null) return false;

        HitResult hit = client.player.pick(range.get(), 1.0F, false);
        if (hit.getType() != HitResult.Type.BLOCK) {
            error("Look at a block first.");
            return false;
        }
        BlockHitResult blockHit = (BlockHitResult) hit;
        railPos = blockHit.getBlockPos().relative(blockHit.getDirection());

        if (!canPlaceAt(railPos)) {
            error("Can't place a rail there (needs free space on solid ground).");
            return false;
        }

        estimatedCart = new AABB(railPos.getX() + 0.01, railPos.getY() + 0.0625, railPos.getZ() + 0.01,
            railPos.getX() + 0.99, railPos.getY() + 0.7625, railPos.getZ() + 0.99);
        Vec3 cc = estimatedCart.getCenter();

        double ux = client.player.getX() - cc.x;
        double uz = client.player.getZ() - cc.z;
        double len = Math.hypot(ux, uz);
        if (len < 1.5) {
            error("Too close to the target, step back.");
            return false;
        }
        ux /= len;
        uz /= len;

        Vec3 origin = arrowOrigin();
        BlockPos playerCell = client.player.blockPosition();
        String lastReason = "no valid fire position";
        boolean found = false;

        outer:
        for (int k = 1; k <= 3; k++) {
            BlockPos f = BlockPos.containing(cc.x + ux * k, railPos.getY(), cc.z + uz * k);
            if (f.equals(railPos) || !canPlaceAt(f)) {
                lastReason = "no room for fire at distance " + k;
                continue;
            }
            BlockPos s = null;
            if (safeMode.get()) {
                s = BlockPos.containing(cc.x + ux * (k + 1), railPos.getY(), cc.z + uz * (k + 1));
                if (s.equals(f) || s.equals(railPos) || !canPlaceAt(s)) {
                    lastReason = "no room for the slab behind the fire";
                    continue;
                }
            }
            if (playerCell.equals(f) || (s != null && playerCell.equals(s))) {
                lastReason = "you are standing where the fire or slab would go";
                continue;
            }

            Solution sol = solveBest(origin, estimatedCart, f, s);
            if (sol.ok) {
                firePos = f;
                slabPos = s;
                found = true;
                debugInfo("Plan: fire " + k + " block(s) from the cart, pitch " + Math.round(sol.pitch * 10) / 10.0);
                break outer;
            }
            lastReason = sol.reason;
        }

        if (!found) {
            error("No valid shot from here: " + lastReason + ". Try moving back a bit or changing position.");
            return false;
        }

        queue.add(Step.RAIL);
        queue.add(Step.CART);
        queue.add(Step.FIRE);
        if (safeMode.get()) queue.add(Step.SLAB);
        queue.add(Step.SHOOT);

        for (Step step : queue) {
            if (!InvUtils.find(predicateFor(step)).found()) {
                error("Missing item for step: " + describe(step));
                queue.clear();
                return false;
            }
        }
        return true;
    }

    private boolean canPlaceAt(BlockPos pos) {
        BlockState state = client.level.getBlockState(pos);
        if (!state.canBeReplaced()) return false;
        BlockPos below = pos.below();
        return client.level.getBlockState(below).isFaceSturdy(client.level, below, Direction.UP);
    }

    private String describe(Step step) {
        return switch (step) {
            case RAIL -> "rail";
            case CART -> "TNT minecart";
            case FIRE -> "flint and steel";
            case SLAB -> "oak/cherry slab";
            case SHOOT -> "charged crossbow";
        };
    }

    private Predicate<ItemStack> predicateFor(Step step) {
        return switch (step) {
            case RAIL -> s -> s.is(Items.RAIL) || s.is(Items.POWERED_RAIL);
            case CART -> s -> s.is(Items.TNT_MINECART);
            case FIRE -> s -> s.is(Items.FLINT_AND_STEEL);
            case SLAB -> s -> s.is(Items.OAK_SLAB) || s.is(Items.CHERRY_SLAB);
            case SHOOT -> s -> s.is(Items.CROSSBOW) && CrossbowItem.isCharged(s);
        };
    }

    private Vec3 aimPoint(Step step) {
        return switch (step) {
            case RAIL -> Vec3.atBottomCenterOf(railPos);
            case CART -> Vec3.atBottomCenterOf(railPos).add(0, 0.1, 0);
            case FIRE -> Vec3.atBottomCenterOf(firePos);
            case SLAB -> Vec3.atBottomCenterOf(slabPos);
            case SHOOT -> Vec3.atBottomCenterOf(railPos).add(0, 0.4, 0);
        };
    }

    // ---------------------------------------------------------------- arrow physics

    /** Where the arrow spawns: your position at eye height minus 0.1. */
    private Vec3 arrowOrigin() {
        return new Vec3(client.player.getX(), client.player.getEyeY() - 0.1, client.player.getZ());
    }

    private Solution solveBest(Vec3 origin, AABB cartBox, BlockPos fire, BlockPos slab) {
        Solution last = Solution.fail("no solution");
        for (double frac : FRACS) {
            Solution s = solve(origin, cartBox, fire, slab, frac);
            if (s.ok) return s;
            last = s;
        }
        return last;
    }

    private Solution solve(Vec3 origin, AABB cartBox, BlockPos fire, BlockPos slab, double frac) {
        Vec3 c = cartBox.getCenter();
        double targetY = cartBox.minY + frac * (cartBox.maxY - cartBox.minY);
        double dx = c.x - origin.x;
        double dz = c.z - origin.z;
        double dist = Math.hypot(dx, dz);
        if (dist < 1.0) return Solution.fail("too close to the cart");

        float yaw = (float) Mth.wrapDegrees(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);

        // Bisection on pitch (positive = down): higher pitch -> arrow lands lower.
        double lo = -45.0, hi = 70.0;
        for (int i = 0; i < 40; i++) {
            double mid = (lo + hi) / 2.0;
            if (heightAt(origin, yaw, mid, dist) > targetY) lo = mid;
            else hi = mid;
        }
        float pitch = (float) ((lo + hi) / 2.0);

        String problem = checkPath(origin, yaw, pitch, cartBox, fire, slab);
        if (problem != null) return Solution.fail(problem);

        Solution s = new Solution();
        s.ok = true;
        s.yaw = yaw;
        s.pitch = pitch;
        return s;
    }

    /** Height of the arrow when it has travelled {@code dist} blocks horizontally. */
    private double heightAt(Vec3 origin, float yawDeg, double pitchDeg, double dist) {
        double yr = Math.toRadians(yawDeg), pr = Math.toRadians(pitchDeg);
        double vx = -Math.sin(yr) * Math.cos(pr) * ARROW_SPEED;
        double vy = -Math.sin(pr) * ARROW_SPEED;
        double vz = Math.cos(yr) * Math.cos(pr) * ARROW_SPEED;
        double y = origin.y, h = 0;
        for (int i = 0; i < 100; i++) {
            double hv = Math.hypot(vx, vz);
            if (hv < 1.0e-6) return -1000;
            if (h + hv >= dist) return y + vy * ((dist - h) / hv);
            h += hv;
            y += vy;
            vx *= DRAG;
            vz *= DRAG;
            vy = vy * DRAG - GRAVITY;
        }
        return -1000;
    }

    /** Returns null if the arrow lights up in the fire and then hits the cart; otherwise the reason it fails. */
    private String checkPath(Vec3 origin, float yawDeg, float pitchDeg, AABB cartBox, BlockPos fire, BlockPos slab) {
        double yr = Math.toRadians(yawDeg), pr = Math.toRadians(pitchDeg);
        Vec3 p = origin;
        Vec3 v = new Vec3(-Math.sin(yr) * Math.cos(pr) * ARROW_SPEED, -Math.sin(pr) * ARROW_SPEED, Math.cos(yr) * Math.cos(pr) * ARROW_SPEED);

        AABB fireBox = new AABB(fire.getX(), fire.getY(), fire.getZ(), fire.getX() + 1, fire.getY() + igniteHeight.get(), fire.getZ() + 1);
        AABB slabBox = slab == null ? null
            : new AABB(slab.getX(), slab.getY(), slab.getZ(), slab.getX() + 1, slab.getY() + 0.5, slab.getZ() + 1);
        AABB cartHit = cartBox.inflate(0.1);
        boolean lit = false;

        for (int t = 0; t < 100; t++) {
            Vec3 n = p.add(v);

            double cartD = entryDist(cartHit, p, n);
            double fireD = entryDist(fireBox, p, n);
            if (fireD >= 0 && (cartD < 0 || fireD <= cartD)) lit = true;

            if (slabBox != null) {
                double slabD = entryDist(slabBox, p, n);
                if (slabD >= 0 && (cartD < 0 || slabD < cartD)) return "the arrow would hit the slab";
            }

            BlockHitResult bh = client.level.clip(new ClipContext(p, n, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, client.player));
            if (bh.getType() == HitResult.Type.BLOCK) {
                double bd = p.distanceToSqr(bh.getLocation());
                if (cartD < 0 || bd < cartD) return "the arrow would hit a block at " + bh.getBlockPos().toShortString();
            }

            if (cartD >= 0) return lit ? null : "the arrow reaches the cart without passing through the fire";

            p = n;
            v = new Vec3(v.x * DRAG, v.y * DRAG - GRAVITY, v.z * DRAG);
        }
        return "the arrow never reaches the cart";
    }

    /** Squared distance from {@code a} to where the segment a->b enters the box, or -1 if it doesn't. */
    private double entryDist(AABB box, Vec3 a, Vec3 b) {
        if (box.contains(a)) return 0;
        Optional<Vec3> hit = box.clip(a, b);
        return hit.isPresent() ? a.distanceToSqr(hit.get()) : -1;
    }

    // ---------------------------------------------------------------- step machine

    private void startStep() {
        if (client.player == null || client.level == null) {
            toggle();
            return;
        }

        current = queue.poll();
        if (current == null) {
            beginPost();
            return;
        }

        int slot = equip(predicateFor(current));
        if (slot == EQUIP_FAIL) {
            error("Missing item for step: " + describe(current));
            toggle();
            return;
        }
        if (current == Step.CART) cartSlot = slot;

        actionDone = false;
        if (current == Step.SHOOT) {
            stage = Stage.CART_WAIT;
            phaseStart = System.currentTimeMillis();
            return;
        }

        Vec3 aim = aimPoint(current);
        targetYaw = (float) Rotations.getYaw(aim);
        targetPitch = Mth.clamp((float) Rotations.getPitch(aim), -90f, 90f);
        startRotation();
    }

    private void startRotation() {
        startYaw = client.player.getYRot();
        startPitch = client.player.getXRot();
        phaseStart = System.currentTimeMillis();
        stage = Stage.ROTATING;
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (stage == Stage.IDLE) return;
        if (client.player == null || client.level == null) {
            toggle();
            return;
        }

        long now = System.currentTimeMillis();
        trackArrows(now);

        // Several transitions can happen in one frame, so the speed is not limited by game ticks.
        for (int guard = 0; guard < 12; guard++) {
            if (!advance(now)) break;
            now = System.currentTimeMillis();
        }
    }

    /** Returns true if the stage changed and another transition may be possible right away. */
    private boolean advance(long now) {
        double s = speed.get();

        switch (stage) {
            case ROTATING -> {
                double duration = rotateTime.get() / s;
                double t = (smoothRotation.get() && duration > 0)
                    ? Math.min(1.0, (now - phaseStart) / duration) : 1.0;
                double e = t * t * (3.0 - 2.0 * t);

                float dYaw = Mth.wrapDegrees(targetYaw - startYaw);
                setCamera(startYaw + dYaw * (float) e, startPitch + (targetPitch - startPitch) * (float) e);

                if (t >= 1.0) {
                    performAction(now);
                    return stage != Stage.ROTATING;
                }
                return false;
            }
            case WAITING -> {
                if (!actionDone) {
                    if (now - scheduledAt > 1500) {
                        error("Step timed out.");
                        toggle();
                    }
                    return false;
                }
                if (now - phaseStart >= baseDelay.get() / s) {
                    startStep();
                    return true;
                }
                return false;
            }
            case CART_WAIT -> {
                Entity cart = findCart();
                if (cart == null && now - phaseStart < 1500) return false;
                if (cart == null) {
                    error("The TNT minecart was not placed.");
                    toggle();
                    return false;
                }
                cartRef = cart;
                Solution sol = solveBest(arrowOrigin(), cart.getBoundingBox(), firePos, slabPos);
                if (!sol.ok) {
                    error("Shot cancelled: " + sol.reason + ".");
                    toggle();
                    return false;
                }
                targetYaw = sol.yaw;
                targetPitch = sol.pitch;
                startRotation();
                return true;
            }
            case RESTOCK -> {
                return restockStep(now);
            }
            case RECHARGE -> {
                recharge(now);
                return false;
            }
            case TRACK -> {
                if (now >= trackUntil) {
                    reportTrack();
                    toggle();
                }
                return false;
            }
            default -> {
                return false;
            }
        }
    }

    private void performAction(long now) {
        if (current == Step.SHOOT) {
            shoot(now);
            return;
        }

        switch (current) {
            case RAIL -> clickBlock(railPos.below());
            case CART -> clickBlock(railPos);
            case FIRE -> clickBlock(firePos.below());
            case SLAB -> clickBlock(slabPos.below());
            default -> { }
        }
        actionDone = true;
        phaseStart = System.currentTimeMillis();
        scheduledAt = phaseStart;
        stage = Stage.WAITING;
    }

    private void shoot(long now) {
        // Re-solve with the real cart position and your real position right now (works while walking).
        Entity cart = cartRef != null && !cartRef.isRemoved() ? cartRef : findCart();
        AABB box = cart != null ? cart.getBoundingBox() : estimatedCart;
        Solution sol = solveBest(arrowOrigin(), box, firePos, slabPos);
        if (!sol.ok) {
            error("Shot cancelled: " + sol.reason + ".");
            toggle();
            return;
        }

        snapshotArrows();
        trackUntil = now + 2500;
        scheduledAt = now;
        actionDone = false;
        stage = Stage.WAITING;

        Rotations.rotate(sol.yaw, sol.pitch, 100, true, () -> {
            if (client.player == null || client.level == null) return;
            client.gameMode.useItem(client.player, InteractionHand.MAIN_HAND);
            client.player.swing(InteractionHand.MAIN_HAND);
            actionDone = true;
            phaseStart = System.currentTimeMillis();
            debugInfo("Shot fired.");
        });
    }

    private void clickBlock(BlockPos support) {
        Vec3 hitVec = Vec3.atBottomCenterOf(support.above());
        BlockHitResult result = new BlockHitResult(hitVec, Direction.UP, support, false);
        client.gameMode.useItemOn(client.player, InteractionHand.MAIN_HAND, result);
        client.player.swing(InteractionHand.MAIN_HAND);
    }

    private Entity findCart() {
        AABB area = new AABB(railPos.getX() - 1.5, railPos.getY() - 1.0, railPos.getZ() - 1.5,
            railPos.getX() + 2.5, railPos.getY() + 2.0, railPos.getZ() + 2.5);
        for (Entity e : client.level.getEntities((Entity) null, area, x -> x.getType() == EntityType.TNT_MINECART)) {
            return e;
        }
        return null;
    }

    // ---------------------------------------------------------------- after the shot

    private void beginPost() {
        if (!postBuilt) {
            postBuilt = true;
            if (restock.get()) post.add(Stage.RESTOCK);
            if (autoRecharge.get()) post.add(Stage.RECHARGE);
        }
        nextPost();
    }

    private void nextPost() {
        Stage next = post.poll();
        if (next == null) {
            finish();
            return;
        }
        stage = next;
        restockPhase = 0;
        rechargeBegan = false;
        phaseStart = System.currentTimeMillis();
    }

    private void finish() {
        if (debugMode.get() && System.currentTimeMillis() < trackUntil) {
            stage = Stage.TRACK;
        } else {
            toggle();
        }
    }

    private boolean isTntCart(ItemStack s) {
        return s.is(Items.TNT_MINECART);
    }

    private boolean restockStep(long now) {
        int slot = cartSlot >= 0 ? cartSlot : scratchSlot.get() - 1;

        switch (restockPhase) {
            case 0 -> {
                if (isTntCart(client.player.getInventory().getItem(slot))) {
                    nextPost();   // the slot still has carts, nothing to do
                    return true;
                }
                if (findInMainInventory() < 0) {
                    warning("No more TNT minecarts in the inventory.");
                    nextPost();
                    return true;
                }
                if (openInventory.get()) client.setScreen(new InventoryScreen(client.player));
                restockSlot = slot;
                restockPhase = 1;
                phaseStart = now;
                return false;
            }
            case 1 -> {
                if (openInventory.get() && now - phaseStart < 20) return false;
                int invSlot = findInMainInventory();
                if (invSlot >= 0) {
                    InvUtils.quickSwap().fromId(restockSlot).to(invSlot);
                } else {
                    warning("No more TNT minecarts in the inventory.");
                }
                restockPhase = 2;
                phaseStart = now;
                return false;
            }
            default -> {
                if (openInventory.get() && now - phaseStart < 20) return false;
                if (client.screen instanceof InventoryScreen) client.player.closeContainer();
                nextPost();
                return true;
            }
        }
    }

    private int findInMainInventory() {
        for (int i = 9; i <= 35; i++) {
            if (isTntCart(client.player.getInventory().getItem(i))) return i;
        }
        return -1;
    }

    private void recharge(long now) {
        if (!rechargeBegan) {
            if (equip(s -> s.is(Items.CROSSBOW)) == EQUIP_FAIL) {
                warning("No crossbow to recharge.");
                nextPost();
                return;
            }
            client.options.keyUse.setDown(true);
            holdingUse = true;
            rechargeBegan = true;
            rechargeStart = now;
            return;
        }

        ItemStack held = client.player.getMainHandItem();
        boolean charged = held.is(Items.CROSSBOW) && CrossbowItem.isCharged(held);
        if (charged || !held.is(Items.CROSSBOW) || now - rechargeStart > 5000) {
            releaseUse();
            if (!charged) warning("Crossbow did not recharge (no arrows or fireworks?).");
            nextPost();
        }
    }

    private void releaseUse() {
        if (holdingUse && client.options != null) {
            client.options.keyUse.setDown(false);
        }
        holdingUse = false;
    }

    // ---------------------------------------------------------------- debug tracking

    private void snapshotArrows() {
        arrowsBefore.clear();
        arrowSeen = false;
        arrowLit = false;
        for (Entity e : client.level.entitiesForRendering()) {
            if (e.getType() == EntityType.ARROW) arrowsBefore.add(e.getId());
        }
    }

    private void trackArrows(long now) {
        if (!debugMode.get() || now >= trackUntil || client.level == null) return;
        for (Entity e : client.level.entitiesForRendering()) {
            if (e.getType() == EntityType.ARROW && !arrowsBefore.contains(e.getId())) {
                arrowSeen = true;
                if (e.isOnFire()) arrowLit = true;
            }
        }
    }

    private void reportTrack() {
        if (!debugMode.get()) return;
        String cart = cartRef == null ? "unknown" : (cartRef.isRemoved() ? "destroyed (exploded)" : "still there");
        info("Arrow seen: " + arrowSeen + ", lit: " + arrowLit + ", minecart: " + cart + ".");
    }

    private void debugInfo(String message) {
        if (debugMode.get()) info(message);
    }

    // ---------------------------------------------------------------- helpers

    private void setCamera(float yaw, float pitch) {
        float p = Mth.clamp(pitch, -90f, 90f);
        client.player.setYRot(yaw);
        client.player.setXRot(p);
        client.player.yRotO = yaw;
        client.player.xRotO = p;
    }

    /**
     * Puts a matching item in the main hand, pulling it into the scratch hotbar slot if needed.
     * Returns the hotbar slot used, EQUIP_OK_UNKNOWN_SLOT if it was already in hand, or EQUIP_FAIL.
     */
    private int equip(Predicate<ItemStack> predicate) {
        ItemStack held = client.player.getMainHandItem();
        if (predicate.test(held)) {
            for (int i = 0; i < 9; i++) {
                if (client.player.getInventory().getItem(i) == held) return i;
            }
            return EQUIP_OK_UNKNOWN_SLOT;
        }

        FindItemResult result = InvUtils.find(predicate);
        if (!result.found()) return EQUIP_FAIL;

        if (result.isHotbar()) {
            InvUtils.swap(result.slot(), false);
            return result.slot();
        }
        if (result.isMain()) {
            int scratch = scratchSlot.get() - 1;
            InvUtils.quickSwap().fromId(scratch).to(result.slot());
            InvUtils.swap(scratch, false);
            return scratch;
        }
        return EQUIP_FAIL;
    }
}
