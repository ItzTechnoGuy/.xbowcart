package com.xbowcart.addon.modules;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.function.Predicate;

/**
 * X-Bow Cart: on activation (default key B) it takes the block under the crosshair and, in line
 * (you -> [slab] -> fire -> TNT minecart): places a rail, a TNT minecart on it, fire next to it
 * on your side, optionally a slab between you and the fire (safe mode), then shoots a charged
 * crossbow at the minecart so the arrow flies through the fire. Then the module turns itself off.
 */
public class XBowCart extends Module {
    private enum Step { RAIL, CART, FIRE, SLAB, SHOOT }

    private enum Stage { IDLE, ROTATING, WAITING, RECHARGE }

    private final Minecraft client = Minecraft.getInstance();

    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Double> speed = sg.add(new DoubleSetting.Builder()
        .name("speed")
        .description("Overall speed. 1.0 = normal, lower = slower (down to 0.1), higher = faster (up to 10).")
        .defaultValue(1.0)
        .range(0.1, 10.0)
        .sliderRange(0.1, 10.0)
        .decimalPlaces(1)
        .build());

    private final Setting<Integer> baseDelay = sg.add(new IntSetting.Builder()
        .name("base-delay")
        .description("Delay in ms after each step at speed 1.0 (real delay = this / speed).")
        .defaultValue(150)
        .range(10, 1000)
        .sliderRange(10, 500)
        .build());

    private final Setting<Boolean> smoothRotation = sg.add(new BoolSetting.Builder()
        .name("smooth-rotation")
        .description("Move the camera smoothly to each target instead of snapping.")
        .defaultValue(true)
        .build());

    private final Setting<Integer> rotateTime = sg.add(new IntSetting.Builder()
        .name("rotate-time")
        .description("Camera movement time in ms per step at speed 1.0 (real time = this / speed).")
        .defaultValue(100)
        .range(0, 500)
        .sliderRange(0, 300)
        .visible(smoothRotation::get)
        .build());

    private final Setting<Double> range = sg.add(new DoubleSetting.Builder()
        .name("range")
        .description("How far away the block under the crosshair can be. The server limits block reach to roughly 4.5 blocks.")
        .defaultValue(5.0)
        .range(2.0, 6.0)
        .sliderRange(2.0, 6.0)
        .decimalPlaces(1)
        .build());

    private final Setting<Boolean> safeMode = sg.add(new BoolSetting.Builder()
        .name("safe-mode")
        .description("Places an oak or cherry slab between you and the fire so the blast hits the slab instead of your legs.")
        .defaultValue(true)
        .build());

    private final Setting<Boolean> autoRecharge = sg.add(new BoolSetting.Builder()
        .name("auto-recharge")
        .description("After shooting, hold use until the crossbow is charged again (needs arrows or fireworks).")
        .defaultValue(true)
        .build());

    private final Setting<Integer> scratchSlot = sg.add(new IntSetting.Builder()
        .name("scratch-hotbar-slot")
        .description("Hotbar slot (1-9) used when an item has to be pulled from the main inventory.")
        .defaultValue(9)
        .range(1, 9)
        .sliderRange(1, 9)
        .build());

    private final ArrayDeque<Step> queue = new ArrayDeque<>();
    private Stage stage = Stage.IDLE;
    private Step current;
    private BlockPos railPos, firePos, slabPos;
    private long phaseStart, scheduledAt, rechargeStart;
    private float startYaw, startPitch, targetYaw, targetPitch;
    private boolean actionDone, rechargeQueued, rechargeBegan, holdingUse;

    public XBowCart() {
        super(Categories.Combat, "x-bow-cart", "Places a rail, TNT minecart and fire at the crosshair block, then shoots the cart with a crossbow.");
        keybind.set(true, GLFW.GLFW_KEY_B, 0);
    }

    @Override
    public void onActivate() {
        queue.clear();
        current = null;
        stage = Stage.IDLE;
        actionDone = false;
        rechargeQueued = false;
        rechargeBegan = false;
        holdingUse = false;

        if (!prepare()) {
            toggle();
            return;
        }
        startStep();
    }

    @Override
    public void onDeactivate() {
        releaseUse();
        stage = Stage.IDLE;
        queue.clear();
    }

    // ---------------------------------------------------------------- preparation

    private boolean prepare() {
        if (client.player == null || client.level == null) return false;

        HitResult hit = client.player.pick(range.get(), 1.0F, false);
        if (hit.getType() != HitResult.Type.BLOCK) {
            error("Look at a block first.");
            return false;
        }
        BlockHitResult blockHit = (BlockHitResult) hit;
        railPos = blockHit.getBlockPos().relative(blockHit.getDirection());

        if (!canPlaceAt(railPos)) {
            error("Can't place a rail there (needs free space on solid ground).");
            return false;
        }

        // Direction from the rail toward the player (dominant horizontal axis).
        Vec3 pos = client.player.position();
        double dx = pos.x - (railPos.getX() + 0.5);
        double dz = pos.z - (railPos.getZ() + 0.5);
        Direction toPlayer = Math.abs(dx) >= Math.abs(dz)
            ? (dx >= 0 ? Direction.EAST : Direction.WEST)
            : (dz >= 0 ? Direction.SOUTH : Direction.NORTH);

        double dist = Math.max(Math.abs(dx), Math.abs(dz));
        if (dist < (safeMode.get() ? 2.5 : 1.5)) {
            error("Too close to the target, step back.");
            return false;
        }

        firePos = railPos.relative(toPlayer);
        if (!canPlaceAt(firePos)) {
            error("No room for fire next to the rail (needs free space on solid ground).");
            return false;
        }

        slabPos = null;
        if (safeMode.get()) {
            slabPos = firePos.relative(toPlayer);
            if (!canPlaceAt(slabPos)) {
                error("No room for the safe-mode slab (needs free space on solid ground).");
                return false;
            }
        }

        queue.add(Step.RAIL);
        queue.add(Step.CART);
        queue.add(Step.FIRE);
        if (safeMode.get()) queue.add(Step.SLAB);
        queue.add(Step.SHOOT);

        for (Step step : queue) {
            if (!InvUtils.find(predicateFor(step)).found()) {
                error("Missing item for step: " + describe(step));
                queue.clear();
                return false;
            }
        }
        return true;
    }

    private boolean canPlaceAt(BlockPos pos) {
        BlockState state = client.level.getBlockState(pos);
        if (!state.canBeReplaced()) return false;
        BlockPos below = pos.below();
        return client.level.getBlockState(below).isFaceSturdy(client.level, below, Direction.UP);
    }

    private String describe(Step step) {
        return switch (step) {
            case RAIL -> "rail";
            case CART -> "TNT minecart";
            case FIRE -> "flint and steel";
            case SLAB -> "oak/cherry slab";
            case SHOOT -> "charged crossbow";
        };
    }

    private Predicate<ItemStack> predicateFor(Step step) {
        return switch (step) {
            case RAIL -> s -> s.is(Items.RAIL) || s.is(Items.POWERED_RAIL);
            case CART -> s -> s.is(Items.TNT_MINECART);
            case FIRE -> s -> s.is(Items.FLINT_AND_STEEL);
            case SLAB -> s -> s.is(Items.OAK_SLAB) || s.is(Items.CHERRY_SLAB);
            case SHOOT -> s -> s.is(Items.CROSSBOW) && CrossbowItem.isCharged(s);
        };
    }

    private Vec3 aimPoint(Step step) {
        return switch (step) {
            case RAIL -> Vec3.atBottomCenterOf(railPos);
            case CART -> Vec3.atBottomCenterOf(railPos).add(0, 0.1, 0);
            case FIRE -> Vec3.atBottomCenterOf(firePos);
            case SLAB -> Vec3.atBottomCenterOf(slabPos);
            // Aim at the minecart itself so the arrow passes through the fire cell first.
            case SHOOT -> Vec3.atBottomCenterOf(railPos).add(0, 0.45, 0);
        };
    }

    // ---------------------------------------------------------------- step machine

    private void startStep() {
        if (client.player == null || client.level == null) {
            toggle();
            return;
        }

        current = queue.poll();
        if (current == null) {
            if (autoRecharge.get() && !rechargeQueued) {
                rechargeQueued = true;
                rechargeBegan = false;
                stage = Stage.RECHARGE;
                return;
            }
            toggle();
            return;
        }

        if (!equip(predicateFor(current))) {
            error("Missing item for step: " + describe(current));
            toggle();
            return;
        }

        Vec3 aim = aimPoint(current);
        targetYaw = (float) Rotations.getYaw(aim);
        targetPitch = Mth.clamp((float) Rotations.getPitch(aim), -90f, 90f);
        startYaw = client.player.getYRot();
        startPitch = client.player.getXRot();
        actionDone = false;
        phaseStart = System.currentTimeMillis();
        stage = Stage.ROTATING;
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (stage == Stage.IDLE) return;
        if (client.player == null || client.level == null) {
            toggle();
            return;
        }

        long now = System.currentTimeMillis();
        double s = speed.get();

        switch (stage) {
            case ROTATING -> {
                double duration = rotateTime.get() / s;
                double t = (smoothRotation.get() && duration > 0)
                    ? Math.min(1.0, (now - phaseStart) / duration) : 1.0;
                double e = t * t * (3.0 - 2.0 * t); // smoothstep easing

                setCamera(startYaw + (targetYaw - startYaw) * (float) e,
                          startPitch + (targetPitch - startPitch) * (float) e);

                if (t >= 1.0) {
                    scheduledAt = now;
                    Rotations.rotate(targetYaw, targetPitch, 100, true, this::performAction);
                    stage = Stage.WAITING;
                }
            }
            case WAITING -> {
                if (!actionDone) {
                    if (now - scheduledAt > 1500) {
                        error("Step timed out.");
                        toggle();
                    }
                } else if (now - phaseStart >= baseDelay.get() / s) {
                    startStep();
                }
            }
            case RECHARGE -> recharge(now);
            default -> { }
        }
    }

    private void performAction() {
        if (client.player == null || client.level == null || current == null) return;

        switch (current) {
            case RAIL -> clickBlock(railPos.below());
            case CART -> clickBlock(railPos);
            case FIRE -> clickBlock(firePos.below());
            case SLAB -> clickBlock(slabPos.below());
            case SHOOT -> {
                client.gameMode.useItem(client.player, InteractionHand.MAIN_HAND);
                client.player.swing(InteractionHand.MAIN_HAND);
            }
        }

        actionDone = true;
        phaseStart = System.currentTimeMillis();
    }

    private void clickBlock(BlockPos support) {
        Vec3 hitVec = Vec3.atBottomCenterOf(support.above());
        BlockHitResult result = new BlockHitResult(hitVec, Direction.UP, support, false);
        client.gameMode.useItemOn(client.player, InteractionHand.MAIN_HAND, result);
        client.player.swing(InteractionHand.MAIN_HAND);
    }

    private void recharge(long now) {
        if (!rechargeBegan) {
            if (!equip(s -> s.is(Items.CROSSBOW))) {
                warning("No crossbow to recharge.");
                toggle();
                return;
            }
            client.options.keyUse.setDown(true);
            holdingUse = true;
            rechargeBegan = true;
            rechargeStart = now;
            return;
        }

        ItemStack held = client.player.getMainHandItem();
        boolean charged = held.is(Items.CROSSBOW) && CrossbowItem.isCharged(held);
        if (charged || !held.is(Items.CROSSBOW) || now - rechargeStart > 5000) {
            releaseUse();
            if (!charged) warning("Crossbow did not recharge (no arrows or fireworks?).");
            toggle();
        }
    }

    private void releaseUse() {
        if (holdingUse && client.options != null) {
            client.options.keyUse.setDown(false);
        }
        holdingUse = false;
    }

    // ---------------------------------------------------------------- helpers

    private void setCamera(float yaw, float pitch) {
        float p = Mth.clamp(pitch, -90f, 90f);
        client.player.setYRot(yaw);
        client.player.setXRot(p);
        client.player.yRotO = yaw;
        client.player.xRotO = p;
    }

    /** Puts a matching item in the main hand, pulling it into the scratch hotbar slot if needed. */
    private boolean equip(Predicate<ItemStack> predicate) {
        if (predicate.test(client.player.getMainHandItem())) return true;

        FindItemResult result = InvUtils.find(predicate);
        if (!result.found()) return false;

        if (result.isHotbar()) {
            InvUtils.swap(result.slot(), false);
            return true;
        }
        if (result.isMain()) {
            int scratch = scratchSlot.get() - 1;
            InvUtils.quickSwap().fromId(scratch).to(result.slot());
            InvUtils.swap(scratch, false);
            return true;
        }
        return false;
    }
}
