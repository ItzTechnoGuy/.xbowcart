package com.xbowcart.addon.modules;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.KeybindSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.Predicate;

/**
 * X-Bow Cart 1.3 by ItzTechnoGuy.
 *
 * Order when everything is on:
 *  1. Load: open the inventory once and put the managed items (rail, TNT minecart, flint and steel,
 *     slab, crossbow) into their own hotbar slots.
 *  2. Run: rail, TNT minecart, fire, slab, shoot (checked, retried up to 3 times).
 *  3. Refill: put a new TNT minecart into the cart slot.
 *  4. Recharge: draw the crossbow for the charge time, release, check it is loaded (up to 3 tries).
 *  5. Return: after the return delay, open the inventory and undo the load swaps in reverse order.
 *
 * The aim comes from a simulation of the crossbow arrow (speed 3.15, drag 0.99, gravity 0.05). The
 * simulation only produces warnings, it never stops the shot. Nothing waits for game ticks.
 */
public class XBowCart extends Module {
    /** Hotbar slot (0-8) the TNT minecart was last used from. Read by TNT Cart Refill. */
    public static volatile int lastCartSlot = -1;

    public enum Timing { Step, Total }

    private enum Step { RAIL, CART, FIRE, SLAB, SHOOT }

    private enum Stage { IDLE, SESSION, ROTATING, SHOT_VERIFY, RECHARGE, RETURN_WAIT, TRACK }

    private enum Post { REFILL, RECHARGE, RETURN }

    private enum After { STEPS, POST }

    private static final double ARROW_SPEED = 3.15;
    private static final double DRAG = 0.99;
    private static final double GRAVITY = 0.05;
    private static final double ARROW_HALF = 0.25;
    private static final double[] FRACS = {0.4, 0.25, 0.55, 0.7, 0.15};

    private static class Solution {
        boolean ok;
        float yaw, pitch;
        String reason = "";
    }

    private final Minecraft client = Minecraft.getInstance();
    private final InvSession session = new InvSession();

    private final SettingGroup sg = settings.getDefaultGroup();
    private final SettingGroup sgItems = settings.createGroup("Items");
    private final SettingGroup sgInv = settings.createGroup("Inventory");
    private final SettingGroup sgCrossbow = settings.createGroup("Crossbow");
    private final SettingGroup sgCircle = settings.createGroup("Circle");

    // ---- General

    private final Setting<Boolean> maxSpeed = sg.add(new BoolSetting.Builder()
        .name("max-speed")
        .description("Everything as fast as possible: no step delay, no camera animation. The server tick and the arrow flight time still apply.")
        .defaultValue(false)
        .build());

    private final Setting<Timing> timingMode = sg.add(new EnumSetting.Builder<Timing>()
        .name("timing-mode")
        .description("Step: set the delay between steps. Total: set the time from the start of the sequence until the crossbow has fired.")
        .defaultValue(Timing.Step)
        .visible(() -> !maxSpeed.get())
        .build());

    private final Setting<Integer> totalTime = sg.add(new IntSetting.Builder()
        .name("total-time")
        .description("Time from the start of the sequence (after the inventory load) until the shot is sent, in ms. The steps are spread evenly. The real limit is about one frame (16 ms at 60 fps); debug mode prints the measured time.")
        .defaultValue(50)
        .range(0, 2000)
        .sliderRange(0, 500)
        .visible(() -> !maxSpeed.get() && timingMode.get() == Timing.Total)
        .build());

    private final Setting<Integer> stepDelay = sg.add(new IntSetting.Builder()
        .name("step-delay")
        .description("Minimum time between two steps, in ms.")
        .defaultValue(20)
        .range(0, 500)
        .sliderRange(0, 200)
        .visible(() -> !maxSpeed.get() && timingMode.get() == Timing.Step)
        .build());

    private final Setting<Boolean> smoothRotation = sg.add(new BoolSetting.Builder()
        .name("smooth-rotation")
        .description("Move the camera smoothly to each target instead of snapping.")
        .defaultValue(true)
        .visible(() -> !maxSpeed.get())
        .build());

    private final Setting<Integer> rotateTime = sg.add(new IntSetting.Builder()
        .name("rotate-time")
        .description("Camera movement time per step, in ms (runs together with the step delay).")
        .defaultValue(20)
        .range(0, 300)
        .sliderRange(0, 200)
        .visible(() -> !maxSpeed.get() && timingMode.get() == Timing.Step && smoothRotation.get())
        .build());

    private final Setting<Double> range = sg.add(new DoubleSetting.Builder()
        .name("range")
        .description("How far away the block under the crosshair can be. The server limits block reach to roughly 4.5 blocks.")
        .defaultValue(5.0)
        .range(2.0, 6.0)
        .sliderRange(2.0, 6.0)
        .decimalPlaces(1)
        .build());

    private final Setting<Boolean> safeMode = sg.add(new BoolSetting.Builder()
        .name("safe-mode")
        .description("Places an oak or cherry slab between you and the fire. If there is no room or no slab, it just continues without it.")
        .defaultValue(true)
        .build());

    private final Setting<Double> igniteHeight = sg.add(new DoubleSetting.Builder()
        .name("ignite-height")
        .description("Height of the fire cell in which a passing arrow gets lit (1.0 = the whole block).")
        .defaultValue(1.0)
        .range(0.1, 1.0)
        .sliderRange(0.1, 1.0)
        .decimalPlaces(2)
        .build());

    private final Setting<Boolean> debugMode = sg.add(new BoolSetting.Builder()
        .name("debug")
        .description("Print what happens (aim, shot result, recharge, inventory swaps) and whether the arrow was lit and the cart exploded.")
        .defaultValue(false)
        .build());

    // ---- Items: each one can be managed (brought to its own hotbar slot from the inventory)

    private final Setting<Boolean> manageRail = sgItems.add(new BoolSetting.Builder()
        .name("manage-rail").description("Bring the rail to its hotbar slot from the inventory. Off: it must already be in the hotbar.")
        .defaultValue(true).build());
    private final Setting<Integer> railSlot = sgItems.add(new IntSetting.Builder()
        .name("rail-slot").description("Hotbar slot (1-9) for the rail.")
        .defaultValue(2).range(1, 9).sliderRange(1, 9).visible(manageRail::get).build());

    private final Setting<Boolean> manageCart = sgItems.add(new BoolSetting.Builder()
        .name("manage-tnt-minecart").description("Bring the TNT minecart to its hotbar slot from the inventory. Off: it must already be in the hotbar.")
        .defaultValue(true).build());
    private final Setting<Integer> cartSlot = sgItems.add(new IntSetting.Builder()
        .name("tnt-minecart-slot").description("Hotbar slot (1-9) for the TNT minecart.")
        .defaultValue(7).range(1, 9).sliderRange(1, 9).visible(manageCart::get).build());

    private final Setting<Boolean> manageFlint = sgItems.add(new BoolSetting.Builder()
        .name("manage-flint-and-steel").description("Bring the flint and steel to its hotbar slot from the inventory. Off: it must already be in the hotbar.")
        .defaultValue(true).build());
    private final Setting<Integer> flintSlot = sgItems.add(new IntSetting.Builder()
        .name("flint-and-steel-slot").description("Hotbar slot (1-9) for the flint and steel.")
        .defaultValue(5).range(1, 9).sliderRange(1, 9).visible(manageFlint::get).build());

    private final Setting<Boolean> manageSlab = sgItems.add(new BoolSetting.Builder()
        .name("manage-slab").description("Bring the oak/cherry slab to its hotbar slot from the inventory. Off: it must already be in the hotbar.")
        .defaultValue(true).build());
    private final Setting<Integer> slabSlot = sgItems.add(new IntSetting.Builder()
        .name("slab-slot").description("Hotbar slot (1-9) for the slab.")
        .defaultValue(4).range(1, 9).sliderRange(1, 9).visible(manageSlab::get).build());

    private final Setting<Boolean> manageCrossbow = sgItems.add(new BoolSetting.Builder()
        .name("manage-crossbow").description("Bring the crossbow to its hotbar slot from the inventory. Off: it must already be in the hotbar.")
        .defaultValue(false).build());
    private final Setting<Integer> crossbowSlot = sgItems.add(new IntSetting.Builder()
        .name("crossbow-slot").description("Hotbar slot (1-9) for the crossbow.")
        .defaultValue(1).range(1, 9).sliderRange(1, 9).visible(manageCrossbow::get).build());

    // ---- Inventory

    private final Setting<Boolean> openInventory = sgInv.add(new BoolSetting.Builder()
        .name("open-inventory")
        .description("Show the inventory screen while swapping items.")
        .defaultValue(true).build());
    private final Setting<Timing> inventoryTiming = sgInv.add(new EnumSetting.Builder<Timing>()
        .name("inventory-timing")
        .description("Step: set each wait yourself. Total: set one time for a whole inventory visit (it is split automatically).")
        .defaultValue(Timing.Step).build());
    private final Setting<Integer> inventoryTotal = sgInv.add(new IntSetting.Builder()
        .name("inventory-total-time")
        .description("Time for one whole inventory visit (open, swaps, check, close), in ms.")
        .defaultValue(150).range(20, 2000).sliderRange(20, 600)
        .visible(() -> inventoryTiming.get() == Timing.Total).build());
    private final Setting<Integer> waitBeforeClick = sgInv.add(new IntSetting.Builder()
        .name("wait-before-click")
        .description("Time between opening the inventory and the first swap, in ms (never in the same frame).")
        .defaultValue(40).range(0, 500).sliderRange(0, 200)
        .visible(() -> inventoryTiming.get() == Timing.Step).build());
    private final Setting<Integer> clickDelay = sgInv.add(new IntSetting.Builder()
        .name("click-delay")
        .description("Time between two swaps in one inventory visit, in ms.")
        .defaultValue(30).range(0, 300).sliderRange(0, 200)
        .visible(() -> inventoryTiming.get() == Timing.Step).build());
    private final Setting<Integer> verifyWait = sgInv.add(new IntSetting.Builder()
        .name("verify-wait")
        .description("How long to wait after the swaps before checking they worked (failed swaps are redone up to 2 times), in ms.")
        .defaultValue(80).range(20, 500).sliderRange(20, 300)
        .visible(() -> inventoryTiming.get() == Timing.Step).build());
    private final Setting<Boolean> waitUntilStill = sgInv.add(new BoolSetting.Builder()
        .name("wait-until-still")
        .description("Wait (up to 1.5 s) until you have stopped moving before swapping.")
        .defaultValue(false).build());
    private final Setting<Boolean> returnItems = sgInv.add(new BoolSetting.Builder()
        .name("return-items")
        .description("After shooting, put every swapped item back where it was.")
        .defaultValue(true).build());
    private final Setting<Integer> returnDelay = sgInv.add(new IntSetting.Builder()
        .name("return-delay")
        .description("Time after the shot before the items are put back, in ms (it never happens before the refill and recharge are finished).")
        .defaultValue(500).range(0, 5000).sliderRange(0, 2000).visible(returnItems::get).build());

    private final Setting<Keybind> refillKey = sgInv.add(new KeybindSetting.Builder()
        .name("refill-key")
        .description("Press this key (module can be off) to open the inventory and put a TNT minecart into the refill slot.")
        .defaultValue(Keybind.none()).build());
    private final Setting<Boolean> refillFixed = sgInv.add(new BoolSetting.Builder()
        .name("refill-use-fixed-slot")
        .description("On: always refill into the refill slot below. Off: into the hotbar slot the last TNT minecart came from.")
        .defaultValue(true).build());
    private final Setting<Integer> refillSlotSetting = sgInv.add(new IntSetting.Builder()
        .name("refill-slot")
        .description("Hotbar slot (1-9) for the TNT minecart refill.")
        .defaultValue(7).range(1, 9).sliderRange(1, 9).build());

    // ---- Circle

    private final Setting<Boolean> showCircle = sgCircle.add(new BoolSetting.Builder()
        .name("show-circle")
        .description("Draw a circle around you on the ground that shows where you can place blocks.")
        .defaultValue(true).build());
    private final Setting<Double> circleRadius = sgCircle.add(new DoubleSetting.Builder()
        .name("circle-radius")
        .description("Radius of the circle in blocks (normal block reach is about 4.5).")
        .defaultValue(4.5).range(1.0, 8.0).sliderRange(1.0, 8.0).decimalPlaces(1)
        .visible(showCircle::get).build());
    private final Setting<SettingColor> circleColor = sgCircle.add(new ColorSetting.Builder()
        .name("circle-color")
        .description("Colour of the circle line.")
        .defaultValue(new SettingColor(145, 61, 226, 255))
        .visible(showCircle::get).build());

    // ---- Crossbow

    private final Setting<Boolean> refillCart = sgCrossbow.add(new BoolSetting.Builder()
        .name("refill-tnt-minecart")
        .description("After shooting, put a new TNT minecart into the refill slot (see Inventory settings).")
        .defaultValue(false).build());
    private final Setting<Boolean> autoRecharge = sgCrossbow.add(new BoolSetting.Builder()
        .name("auto-recharge")
        .description("After shooting, draw the crossbow again (needs arrows or fireworks).")
        .defaultValue(true).build());
    private final Setting<Integer> chargeTime = sgCrossbow.add(new IntSetting.Builder()
        .name("charge-time")
        .description("How long to draw the crossbow, in ms. Vanilla 1250, Quick Charge I/II/III = 1000/750/500. If it fails it retries with a longer time.")
        .defaultValue(1250).range(200, 3000).sliderRange(400, 2000).visible(autoRecharge::get).build());

    // ---- State

    private final ArrayDeque<Step> queue = new ArrayDeque<>();
    private final ArrayDeque<Post> post = new ArrayDeque<>();
    private final List<InvSession.Op> preload = new ArrayList<>();
    private final Set<Integer> arrowsBefore = new HashSet<>();

    private Stage stage = Stage.IDLE;
    private After sessionAfter = After.STEPS;
    private Step current;
    private BlockPos railPos, firePos, slabPos;
    private AABB estimatedCart;
    private Entity cartRef;
    private long phaseStart, lastAction, shotTime, verifyStart, trackUntil, rechargeT;
    private float startYaw, startPitch, targetYaw, targetPitch;
    private int shotTries, rechargePhase, rechargeAttempt;
    private boolean postBuilt, holdingUse, arrowSeen, arrowLit;
    private long seqStart, actAt, rotDuration;
    private int stepIndex, stepCount;
    private boolean sequenceStarted;
    private final InvSession manualSession = new InvSession();
    private boolean manualRunning;

    public XBowCart() {
        super(Categories.Combat, "x-bow-cart", "Places a rail, TNT minecart and fire at the crosshair block, then shoots the cart with a crossbow. By ItzTechnoGuy.");
        keybind.set(true, GLFW.GLFW_KEY_B, 0);
    }

    @Override
    public void onActivate() {
        queue.clear();
        post.clear();
        preload.clear();
        arrowsBefore.clear();
        current = null;
        cartRef = null;
        stage = Stage.IDLE;
        postBuilt = false;
        holdingUse = false;
        arrowSeen = false;
        arrowLit = false;
        trackUntil = 0;
        lastAction = 0;
        shotTime = 0;
        sequenceStarted = false;
        stepIndex = 0;

        if (!prepare()) {
            toggle();
            return;
        }

        if (!preload.isEmpty()) {
            startSession(preload, After.STEPS);
        } else {
            startStep();
        }
    }

    @Override
    public void onDeactivate() {
        releaseUse();
        session.abort();
        stage = Stage.IDLE;
        queue.clear();
        post.clear();
    }

    private int effRotateTime() {
        return (maxSpeed.get() || !smoothRotation.get()) ? 0 : rotateTime.get();
    }

    // ---------------------------------------------------------------- preparation

    private boolean prepare() {
        if (client.player == null || client.level == null) return false;

        HitResult hit = client.player.pick(range.get(), 1.0F, false);
        if (hit.getType() != HitResult.Type.BLOCK) {
            error("Look at a block first.");
            return false;
        }
        BlockHitResult blockHit = (BlockHitResult) hit;
        railPos = blockHit.getBlockPos().relative(blockHit.getDirection());

        if (!canPlaceAt(railPos)) {
            error("Can't place a rail there (needs free space on solid ground).");
            return false;
        }

        estimatedCart = new AABB(railPos.getX() + 0.01, railPos.getY() + 0.0625, railPos.getZ() + 0.01,
            railPos.getX() + 0.99, railPos.getY() + 0.7625, railPos.getZ() + 0.99);
        Vec3 cc = estimatedCart.getCenter();

        // Horizontal direction from the cart toward you.
        double ux = client.player.getX() - cc.x;
        double uz = client.player.getZ() - cc.z;
        double len = Math.hypot(ux, uz);
        if (len < 0.3) {
            ux = 1;
            uz = 0;
        } else {
            ux /= len;
            uz /= len;
        }

        Vec3 origin = arrowOrigin();
        BlockPos playerCell = client.player.blockPosition();
        BlockPos bestFire = null, bestSlab = null;
        Solution bestSol = null;
        String lastReason = "no free cell with solid ground";

        for (int k = 1; k <= 3; k++) {
            BlockPos f = findPlaceable(cc.x + ux * k, cc.z + uz * k, railPos.getY());
            if (f == null || f.equals(railPos) || f.equals(playerCell)) continue;

            BlockPos s = null;
            if (safeMode.get()) {
                s = findPlaceable(cc.x + ux * (k + 1), cc.z + uz * (k + 1), railPos.getY());
                if (s != null && (s.equals(f) || s.equals(railPos) || s.equals(playerCell))) s = null;
            }

            Solution sol = solveBest(origin, estimatedCart, f, s);
            if (bestSol == null) {
                bestFire = f;
                bestSlab = s;
                bestSol = sol;
            }
            if (sol.ok) {
                bestFire = f;
                bestSlab = s;
                bestSol = sol;
                break;
            }
            lastReason = sol.reason;
        }

        if (bestFire == null) {
            error("No place for the fire next to the cart: " + lastReason + ".");
            return false;
        }

        firePos = bestFire;
        slabPos = bestSlab;
        if (safeMode.get() && slabPos == null) warning("No room for the slab, continuing without it.");
        if (!bestSol.ok) warning("The shot might not work (" + bestSol.reason + "). Shooting anyway.");
        debugInfo("Fire at " + firePos.toShortString() + ", pitch " + Math.round(bestSol.pitch * 10) / 10.0);

        if (!planPreload()) return false;

        queue.add(Step.RAIL);
        queue.add(Step.CART);
        queue.add(Step.FIRE);
        if (slabPos != null) queue.add(Step.SLAB);
        queue.add(Step.SHOOT);
        return true;
    }

    /**
     * Works out which items have to be brought to their hotbar slots, on a virtual copy of the
     * inventory so that every swap is planned with the effect of the earlier ones.
     */
    private boolean planPreload() {
        preload.clear();

        ItemStack[] virt = new ItemStack[36];
        for (int i = 0; i < 36; i++) virt[i] = client.player.getInventory().getItem(i);

        List<Step> steps = new ArrayList<>();
        steps.add(Step.RAIL);
        steps.add(Step.CART);
        steps.add(Step.FIRE);
        if (slabPos != null) steps.add(Step.SLAB);
        steps.add(Step.SHOOT);

        for (Step st : steps) {
            Predicate<ItemStack> pred = predicateFor(st);
            int target = managedSlot(st);

            if (target >= 0 && pred.test(virt[target])) continue;

            boolean inHotbar = false;
            for (int i = 0; i < 9; i++) {
                if (pred.test(virt[i])) {
                    inHotbar = true;
                    break;
                }
            }
            if (inHotbar) continue;

            int src = -1;
            if (target >= 0) {
                for (int i = 9; i <= 35; i++) {
                    if (pred.test(virt[i])) {
                        src = i;
                        break;
                    }
                }
            }

            if (src < 0) {
                if (st == Step.SLAB) {
                    warning("No slab found, continuing without it.");
                    slabPos = null;
                    continue;
                }
                error("Missing item for step: " + describe(st)
                    + (target < 0 ? " (it has to be in the hotbar because its manage option is off)." : "."));
                return false;
            }

            preload.add(new InvSession.Op(target, src, virt[src].getItem(), virt[target].getItem()));
            ItemStack tmp = virt[target];
            virt[target] = virt[src];
            virt[src] = tmp;
        }
        return true;
    }

    private int managedSlot(Step st) {
        return switch (st) {
            case RAIL -> manageRail.get() ? railSlot.get() - 1 : -1;
            case CART -> manageCart.get() ? cartSlot.get() - 1 : -1;
            case FIRE -> manageFlint.get() ? flintSlot.get() - 1 : -1;
            case SLAB -> manageSlab.get() ? slabSlot.get() - 1 : -1;
            case SHOOT -> manageCrossbow.get() ? crossbowSlot.get() - 1 : -1;
        };
    }

    /** Finds a free cell with solid ground in this column, at the base height or one block lower/higher. */
    private BlockPos findPlaceable(double x, double z, int baseY) {
        int[] offsets = {0, -1, 1};
        for (int dy : offsets) {
            BlockPos p = BlockPos.containing(x, baseY + dy, z);
            if (canPlaceAt(p)) return p;
        }
        return null;
    }

    private boolean canPlaceAt(BlockPos pos) {
        BlockState state = client.level.getBlockState(pos);
        if (!state.canBeReplaced()) return false;
        BlockPos below = pos.below();
        return client.level.getBlockState(below).isFaceSturdy(client.level, below, Direction.UP);
    }

    private String describe(Step step) {
        return switch (step) {
            case RAIL -> "rail";
            case CART -> "TNT minecart";
            case FIRE -> "flint and steel";
            case SLAB -> "oak/cherry slab";
            case SHOOT -> "charged crossbow";
        };
    }

    private Predicate<ItemStack> predicateFor(Step step) {
        return switch (step) {
            case RAIL -> s -> s.is(Items.RAIL) || s.is(Items.POWERED_RAIL);
            case CART -> s -> s.is(Items.TNT_MINECART);
            case FIRE -> s -> s.is(Items.FLINT_AND_STEEL);
            case SLAB -> s -> s.is(Items.OAK_SLAB) || s.is(Items.CHERRY_SLAB);
            case SHOOT -> s -> s.is(Items.CROSSBOW) && CrossbowItem.isCharged(s);
        };
    }

    private Vec3 aimPoint(Step step) {
        return switch (step) {
            case RAIL -> Vec3.atBottomCenterOf(railPos);
            case CART -> Vec3.atBottomCenterOf(railPos).add(0, 0.1, 0);
            case FIRE -> Vec3.atBottomCenterOf(firePos);
            case SLAB -> Vec3.atBottomCenterOf(slabPos);
            case SHOOT -> Vec3.atBottomCenterOf(railPos).add(0, 0.4, 0);
        };
    }

    // ---------------------------------------------------------------- arrow physics

    /** Where the arrow spawns: your position at eye height minus 0.1. */
    private Vec3 arrowOrigin() {
        return new Vec3(client.player.getX(), client.player.getEyeY() - 0.1, client.player.getZ());
    }

    /** Always returns an aim. {@code ok} tells whether the simulation thinks the shot works. */
    private Solution solveBest(Vec3 origin, AABB cartBox, BlockPos fire, BlockPos slab) {
        Solution first = null;
        for (double frac : FRACS) {
            Solution s = solve(origin, cartBox, fire, slab, frac);
            if (s.ok) return s;
            if (first == null) first = s;
        }
        return first;
    }

    private Solution solve(Vec3 origin, AABB cartBox, BlockPos fire, BlockPos slab, double frac) {
        Vec3 c = cartBox.getCenter();
        double targetY = cartBox.minY + frac * (cartBox.maxY - cartBox.minY);
        double dx = c.x - origin.x;
        double dz = c.z - origin.z;
        double dist = Math.hypot(dx, dz);

        Solution s = new Solution();
        s.yaw = (float) Mth.wrapDegrees(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);

        if (dist < 0.5) {
            s.pitch = (float) -Math.toDegrees(Math.atan2(targetY - origin.y, Math.max(dist, 0.01)));
            s.ok = false;
            s.reason = "too close to the cart";
            return s;
        }

        // Bisection on pitch (positive = down): higher pitch -> arrow lands lower.
        double lo = -45.0, hi = 70.0;
        for (int i = 0; i < 40; i++) {
            double mid = (lo + hi) / 2.0;
            if (heightAt(origin, s.yaw, mid, dist) > targetY) lo = mid;
            else hi = mid;
        }
        s.pitch = (float) ((lo + hi) / 2.0);

        String problem = checkPath(origin, s.yaw, s.pitch, cartBox, fire, slab);
        s.ok = problem == null;
        s.reason = problem == null ? "" : problem;
        return s;
    }

    /** Height of the arrow when it has travelled {@code dist} blocks horizontally. */
    private double heightAt(Vec3 origin, float yawDeg, double pitchDeg, double dist) {
        double yr = Math.toRadians(yawDeg), pr = Math.toRadians(pitchDeg);
        double vx = -Math.sin(yr) * Math.cos(pr) * ARROW_SPEED;
        double vy = -Math.sin(pr) * ARROW_SPEED;
        double vz = Math.cos(yr) * Math.cos(pr) * ARROW_SPEED;
        double y = origin.y, h = 0;
        for (int i = 0; i < 100; i++) {
            double hv = Math.hypot(vx, vz);
            if (hv < 1.0e-6) return -1000;
            if (h + hv >= dist) return y + vy * ((dist - h) / hv);
            h += hv;
            y += vy;
            vx *= DRAG;
            vz *= DRAG;
            vy = vy * DRAG - GRAVITY;
        }
        return -1000;
    }

    /** Returns null if the arrow is lit by the fire and then hits the cart; otherwise the reason it fails. */
    private String checkPath(Vec3 origin, float yawDeg, float pitchDeg, AABB cartBox, BlockPos fire, BlockPos slab) {
        double yr = Math.toRadians(yawDeg), pr = Math.toRadians(pitchDeg);
        Vec3 p = origin;
        Vec3 v = new Vec3(-Math.sin(yr) * Math.cos(pr) * ARROW_SPEED, -Math.sin(pr) * ARROW_SPEED, Math.cos(yr) * Math.cos(pr) * ARROW_SPEED);

        // The arrow is a 0.5 x 0.5 box, so every target box is grown by half of that.
        AABB fireBox = new AABB(fire.getX(), fire.getY(), fire.getZ(), fire.getX() + 1, fire.getY() + igniteHeight.get(), fire.getZ() + 1)
            .inflate(ARROW_HALF);
        AABB slabBox = slab == null ? null
            : new AABB(slab.getX(), slab.getY(), slab.getZ(), slab.getX() + 1, slab.getY() + 0.5, slab.getZ() + 1).inflate(ARROW_HALF);
        AABB cartHit = cartBox.inflate(ARROW_HALF);
        boolean lit = false;

        for (int t = 0; t < 100; t++) {
            Vec3 n = p.add(v);

            double cartD = entryDist(cartHit, p, n);
            double fireD = entryDist(fireBox, p, n);
            if (fireD >= 0 && (cartD < 0 || fireD <= cartD)) lit = true;

            if (slabBox != null) {
                double slabD = entryDist(slabBox, p, n);
                if (slabD >= 0 && (cartD < 0 || slabD < cartD)) return "the arrow would hit the slab";
            }

            BlockHitResult bh = client.level.clip(new ClipContext(p, n, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, client.player));
            if (bh.getType() == HitResult.Type.BLOCK) {
                double bd = p.distanceToSqr(bh.getLocation());
                if (cartD < 0 || bd < cartD) return "the arrow would hit a block at " + bh.getBlockPos().toShortString();
            }

            if (cartD >= 0) return lit ? null : "the arrow reaches the cart without passing through the fire";

            p = n;
            v = new Vec3(v.x * DRAG, v.y * DRAG - GRAVITY, v.z * DRAG);
        }
        return "the arrow never reaches the cart";
    }

    /** Squared distance from {@code a} to where the segment a->b enters the box, or -1 if it doesn't. */
    private double entryDist(AABB box, Vec3 a, Vec3 b) {
        if (box.contains(a)) return 0;
        Optional<Vec3> hit = box.clip(a, b);
        return hit.isPresent() ? a.distanceToSqr(hit.get()) : -1;
    }

    // ---------------------------------------------------------------- inventory sessions

    private void startSession(List<InvSession.Op> ops, After after) {
        configure(session, ops.size());
        session.start(ops, System.currentTimeMillis());
        sessionAfter = after;
        stage = Stage.SESSION;
        debugInfo("Inventory: " + ops.size() + " swap(s).");
    }

    // ---------------------------------------------------------------- step machine

    private void startStep() {
        if (client.player == null || client.level == null) {
            toggle();
            return;
        }

        long startNow = System.currentTimeMillis();
        if (!sequenceStarted) {
            sequenceStarted = true;
            seqStart = startNow;
            stepCount = Math.max(1, queue.size());
        }

        current = queue.poll();
        if (current == null) {
            nextPost();
            return;
        }

        if (!select(current)) {
            error("Missing item for step: " + describe(current) + ".");
            toggle();
            return;
        }

        if (current == Step.SHOOT) {
            Solution sol = solveBest(arrowOrigin(), estimatedCart, firePos, slabPos);
            targetYaw = sol.yaw;
            targetPitch = sol.pitch;
        } else {
            Vec3 aim = aimPoint(current);
            targetYaw = (float) Rotations.getYaw(aim);
            targetPitch = Mth.clamp((float) Rotations.getPitch(aim), -90f, 90f);
        }

        startYaw = client.player.getYRot();
        startPitch = client.player.getXRot();
        phaseStart = System.currentTimeMillis();

        if (maxSpeed.get()) {
            actAt = phaseStart;
            rotDuration = 0;
        } else if (timingMode.get() == Timing.Total) {
            actAt = seqStart + Math.round(totalTime.get() * (double) (stepIndex + 1) / stepCount);
            rotDuration = smoothRotation.get() ? Math.max(0, actAt - phaseStart) : 0;
        } else {
            rotDuration = effRotateTime();
            actAt = Math.max(phaseStart + rotDuration, lastAction + stepDelay.get());
        }
        stage = Stage.ROTATING;
    }

    /** Selects the hotbar slot that holds the item for this step. */
    private boolean select(Step st) {
        return selectMatching(predicateFor(st), managedSlot(st), st == Step.CART);
    }

    private boolean selectMatching(Predicate<ItemStack> pred, int preferred, boolean remember) {
        int slot = -1;
        if (preferred >= 0 && pred.test(client.player.getInventory().getItem(preferred))) {
            slot = preferred;
        } else {
            for (int i = 0; i < 9; i++) {
                if (pred.test(client.player.getInventory().getItem(i))) {
                    slot = i;
                    break;
                }
            }
        }
        if (slot < 0) return false;
        InvUtils.swap(slot, false);
        if (remember) lastCartSlot = slot;
        return true;
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (stage == Stage.IDLE) return;
        if (client.player == null || client.level == null) {
            toggle();
            return;
        }

        trackArrows(System.currentTimeMillis());

        // Several transitions can happen in one frame, so nothing is limited by game ticks.
        for (int guard = 0; guard < 12; guard++) {
            if (!advance(System.currentTimeMillis())) break;
        }
    }

    /** Returns true if the stage changed and another transition may be possible right away. */
    private boolean advance(long now) {
        switch (stage) {
            case SESSION -> {
                if (!session.tick(now)) return false;
                if (session.failed > 0) warning("The server did not accept " + session.failed + " inventory swap(s).");
                if (sessionAfter == After.STEPS) startStep();
                else nextPost();
                return true;
            }
            case ROTATING -> {
                double duration = rotDuration;
                double t = duration > 0 ? Math.min(1.0, (now - phaseStart) / duration) : 1.0;
                double e = t * t * (3.0 - 2.0 * t);

                float dYaw = Mth.wrapDegrees(targetYaw - startYaw);
                setCamera(startYaw + dYaw * (float) e, startPitch + (targetPitch - startPitch) * (float) e);

                if (now >= actAt) {
                    boolean shooting = current == Step.SHOOT;
                    performAction(now);
                    lastAction = System.currentTimeMillis();
                    stepIndex++;
                    if (shooting) {
                        shotTries = 1;
                        verifyStart = lastAction;
                        stage = Stage.SHOT_VERIFY;
                    } else {
                        startStep();
                    }
                    return true;
                }
                return false;
            }
            case SHOT_VERIFY -> {
                return verifyShot(now);
            }
            case RECHARGE -> {
                return rechargeStep(now);
            }
            case RETURN_WAIT -> {
                if (now - shotTime < returnDelay.get()) return false;
                List<InvSession.Op> undo = new ArrayList<>();
                for (int i = preload.size() - 1; i >= 0; i--) {
                    InvSession.Op o = preload.get(i);
                    undo.add(new InvSession.Op(o.hotbar, o.inv, o.hotbarBefore, o.expect));
                }
                startSession(undo, After.POST);
                return true;
            }
            case TRACK -> {
                if (now >= trackUntil) {
                    reportTrack();
                    toggle();
                }
                return false;
            }
            default -> {
                return false;
            }
        }
    }

    private void performAction(long now) {
        switch (current) {
            case RAIL -> clickBlock(railPos.below());
            case CART -> clickBlock(railPos);
            case FIRE -> clickBlock(firePos.below());
            case SLAB -> clickBlock(slabPos.below());
            case SHOOT -> {
                shotTime = now;
                debugInfo("Shot sent " + (now - seqStart) + " ms after the sequence started"
                    + (timingMode.get() == Timing.Total && !maxSpeed.get() ? " (target " + totalTime.get() + " ms)." : "."));
                snapshotArrows();
                trackUntil = now + 2500;
                fireShot(true);
            }
        }
    }

    private void clickBlock(BlockPos support) {
        Vec3 hitVec = Vec3.atBottomCenterOf(support.above());
        BlockHitResult result = new BlockHitResult(hitVec, Direction.UP, support, false);
        client.gameMode.useItemOn(client.player, InteractionHand.MAIN_HAND, result);
        client.player.swing(InteractionHand.MAIN_HAND);
    }

    // ---------------------------------------------------------------- the shot

    private void fireShot(boolean first) {
        if (!select(Step.SHOOT)) {
            warning("No charged crossbow in the hotbar.");
            return;
        }

        // Fresh aim from where you are right now (so walking works). Always fires.
        Entity cart = findCart();
        if (cart != null) cartRef = cart;
        AABB box = cart != null ? cart.getBoundingBox() : estimatedCart;
        Solution sol = solveBest(arrowOrigin(), box, firePos, slabPos);
        if (!sol.ok && first) warning("The shot might not work (" + sol.reason + "). Shooting anyway.");

        setCamera(sol.yaw, sol.pitch);
        sendRotation(sol.yaw, sol.pitch);

        client.gameMode.useItem(client.player, InteractionHand.MAIN_HAND);
        client.player.swing(InteractionHand.MAIN_HAND);
        debugInfo("Shot fired (try " + shotTries + ").");
    }

    /** Waits for proof that the crossbow fired (a new arrow, or the crossbow is empty) and retries up to 3 times. */
    private boolean verifyShot(long now) {
        ItemStack held = client.player.getMainHandItem();
        boolean fired = arrowAppeared() || (held.is(Items.CROSSBOW) && !CrossbowItem.isCharged(held));
        if (fired) {
            debugInfo("Shot confirmed.");
            nextPost();
            return true;
        }
        if (now - verifyStart < 400) return false;

        if (shotTries >= 3) {
            warning("The crossbow did not fire after 3 tries.");
            nextPost();
            return true;
        }
        shotTries++;
        verifyStart = now;
        fireShot(false);
        return false;
    }

    private boolean arrowAppeared() {
        for (Entity e : client.level.entitiesForRendering()) {
            if (e.getType() == EntityType.ARROW && !arrowsBefore.contains(e.getId())) return true;
        }
        return false;
    }

    /** Tells the server the new look direction right away, instead of waiting for the next game tick. */
    private void sendRotation(float yaw, float pitch) {
        if (client.getConnection() == null) return;
        client.getConnection().send(new ServerboundMovePlayerPacket.Rot(yaw, pitch, client.player.onGround(), client.player.horizontalCollision));
    }

    private Entity findCart() {
        AABB area = new AABB(railPos.getX() - 1.5, railPos.getY() - 1.0, railPos.getZ() - 1.5,
            railPos.getX() + 2.5, railPos.getY() + 2.0, railPos.getZ() + 2.5);
        for (Entity e : client.level.getEntities((Entity) null, area, x -> x.getType() == EntityType.TNT_MINECART)) {
            return e;
        }
        return null;
    }

    // ---------------------------------------------------------------- after the shot

    private void nextPost() {
        if (!postBuilt) {
            postBuilt = true;
            if (refillCart.get()) post.add(Post.REFILL);
            if (autoRecharge.get()) post.add(Post.RECHARGE);
            if (returnItems.get() && !preload.isEmpty()) post.add(Post.RETURN);
        }

        Post p = post.poll();
        if (p == null) {
            finish();
            return;
        }
        switch (p) {
            case REFILL -> startRefill();
            case RECHARGE -> {
                rechargePhase = 0;
                rechargeAttempt = 1;
                rechargeT = System.currentTimeMillis();
                stage = Stage.RECHARGE;
            }
            case RETURN -> stage = Stage.RETURN_WAIT;
        }
    }

    private void finish() {
        releaseUse();
        if (debugMode.get() && System.currentTimeMillis() < trackUntil) {
            stage = Stage.TRACK;
        } else {
            toggle();
        }
    }

    /** Hotbar slot (0-8) the refilled TNT minecart goes into. */
    private int refillSlot() {
        int fixed = refillSlotSetting.get() - 1;
        if (refillFixed.get()) return fixed;
        return lastCartSlot >= 0 ? lastCartSlot : fixed;
    }

    /** The swap that puts a TNT minecart from the inventory into the refill slot, or an empty list. */
    private List<InvSession.Op> buildRefillOps() {
        List<InvSession.Op> ops = new ArrayList<>();
        int slot = refillSlot();
        ItemStack inSlot = client.player.getInventory().getItem(slot);
        if (inSlot.is(Items.TNT_MINECART)) {
            debugInfo("Refill skipped: the slot still has TNT minecarts.");
            return ops;
        }

        int best = -1, bestCount = 0;
        for (int i = 9; i <= 35; i++) {
            ItemStack s = client.player.getInventory().getItem(i);
            if (s.is(Items.TNT_MINECART) && s.getCount() > bestCount) {
                best = i;
                bestCount = s.getCount();
            }
        }
        if (best < 0) {
            warning("No more TNT minecarts in the inventory.");
            return ops;
        }
        ops.add(new InvSession.Op(slot, best, Items.TNT_MINECART, inSlot.getItem()));
        return ops;
    }

    private void startRefill() {
        List<InvSession.Op> ops = buildRefillOps();
        if (ops.isEmpty()) {
            nextPost();
            return;
        }
        startSession(ops, After.POST);
    }

    private void configure(InvSession target, int opCount) {
        target.openScreen = openInventory.get();
        target.waitUntilStill = waitUntilStill.get();
        target.timing(inventoryTiming.get() == Timing.Total, inventoryTotal.get(),
            waitBeforeClick.get(), clickDelay.get(), verifyWait.get(), opCount);
    }

    // ---------------------------------------------------------------- always-on parts (called by Overlay)

    /** Key press from anywhere: starts the manual refill if it is your refill key. */
    public void onGlobalKey(int key, int modifiers) {
        if (client.player == null || client.level == null || client.screen != null) return;
        Keybind kb = refillKey.get();
        if (!kb.isSet() || !kb.matches(true, key, modifiers)) return;
        if (stage != Stage.IDLE || manualRunning) return;

        List<InvSession.Op> ops = buildRefillOps();
        if (ops.isEmpty()) return;
        configure(manualSession, ops.size());
        manualSession.start(ops, System.currentTimeMillis());
        manualRunning = true;
    }

    /** Runs the manual refill, even while the module is switched off. */
    public void backgroundTick(long now) {
        if (!manualRunning) return;
        if (client.player == null) {
            manualSession.abort();
            manualRunning = false;
            return;
        }
        if (manualSession.tick(now)) {
            manualRunning = false;
            if (manualSession.failed > 0) warning("The server did not accept the refill swap.");
        }
    }

    /** Draws the placement circle on the ground around you. */
    public void renderCircle(Render3DEvent event) {
        if (!showCircle.get() || client.player == null || client.level == null) return;

        double cx = Mth.lerp(event.tickDelta, client.player.xo, client.player.getX());
        double cy = Mth.lerp(event.tickDelta, client.player.yo, client.player.getY()) + 0.03;
        double cz = Mth.lerp(event.tickDelta, client.player.zo, client.player.getZ());
        double r = circleRadius.get();
        SettingColor color = circleColor.get();

        int segments = 72;
        for (int i = 0; i < segments; i++) {
            double a1 = 2 * Math.PI * i / segments;
            double a2 = 2 * Math.PI * (i + 1) / segments;
            event.renderer.line(cx + r * Math.cos(a1), cy, cz + r * Math.sin(a1),
                cx + r * Math.cos(a2), cy, cz + r * Math.sin(a2), color);
        }
    }

    // ---------------------------------------------------------------- crossbow recharge

    /**
     * Draw the crossbow, hold it for the charge time, release it (that is what loads it) and check.
     * Phases: 0 select + wait until it shows empty, 1 start drawing, 2 hold, 3 confirm.
     */
    private boolean rechargeStep(long now) {
        switch (rechargePhase) {
            case 0 -> {
                if (!selectMatching(s -> s.is(Items.CROSSBOW), manageCrossbow.get() ? crossbowSlot.get() - 1 : -1, false)) {
                    warning("No crossbow to recharge.");
                    nextPost();
                    return true;
                }
                ItemStack held = client.player.getMainHandItem();
                if (held.is(Items.CROSSBOW) && !CrossbowItem.isCharged(held)) {
                    rechargePhase = 1;
                    return true;
                }
                if (now - rechargeT > 600) {
                    warning("The crossbow still looks charged, not recharging.");
                    nextPost();
                    return true;
                }
                return false;
            }
            case 1 -> {
                client.options.keyUse.setDown(true);
                holdingUse = true;
                client.gameMode.useItem(client.player, InteractionHand.MAIN_HAND);
                rechargeT = now;
                rechargePhase = 2;
                return false;
            }
            case 2 -> {
                long hold = chargeTime.get() + 100L + (rechargeAttempt - 1) * 200L;
                if (now - rechargeT < hold) return false;
                client.gameMode.releaseUsingItem(client.player);
                releaseUse();
                rechargeT = now;
                rechargePhase = 3;
                return false;
            }
            default -> {
                ItemStack held = client.player.getMainHandItem();
                if (held.is(Items.CROSSBOW) && CrossbowItem.isCharged(held)) {
                    debugInfo("Crossbow recharged (try " + rechargeAttempt + ").");
                    nextPost();
                    return true;
                }
                if (now - rechargeT > 450) {
                    if (rechargeAttempt < 3) {
                        rechargeAttempt++;
                        rechargePhase = 1;
                        rechargeT = now;
                        debugInfo("Recharge did not work, trying again.");
                    } else {
                        warning("The crossbow did not recharge (no arrows or fireworks?).");
                        nextPost();
                        return true;
                    }
                }
                return false;
            }
        }
    }

    private void releaseUse() {
        if (holdingUse && client.options != null) {
            client.options.keyUse.setDown(false);
        }
        holdingUse = false;
    }

    // ---------------------------------------------------------------- debug tracking

    private void snapshotArrows() {
        arrowsBefore.clear();
        arrowSeen = false;
        arrowLit = false;
        for (Entity e : client.level.entitiesForRendering()) {
            if (e.getType() == EntityType.ARROW) arrowsBefore.add(e.getId());
        }
    }

    private void trackArrows(long now) {
        if (!debugMode.get() || now >= trackUntil || client.level == null) return;
        for (Entity e : client.level.entitiesForRendering()) {
            if (e.getType() == EntityType.ARROW && !arrowsBefore.contains(e.getId())) {
                arrowSeen = true;
                if (e.isOnFire()) arrowLit = true;
            }
        }
    }

    private void reportTrack() {
        if (!debugMode.get()) return;
        String cart = cartRef == null ? "unknown" : (cartRef.isRemoved() ? "destroyed (exploded)" : "still there");
        info("Arrow seen: " + arrowSeen + ", lit: " + arrowLit + ", minecart: " + cart + ".");
    }

    private void debugInfo(String message) {
        if (debugMode.get()) info(message);
    }

    // ---------------------------------------------------------------- helpers

    private void setCamera(float yaw, float pitch) {
        float p = Mth.clamp(pitch, -90f, 90f);
        client.player.setYRot(yaw);
        client.player.setXRot(p);
        client.player.yRotO = yaw;
        client.player.xRotO = p;
    }
}
