package com.xbowcart.addon.modules;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * TNT Cart Refill: one key press opens the inventory, finds a TNT minecart and swaps it into the
 * chosen hotbar slot (same as hovering the item and pressing the number key, not shift-click),
 * so whatever was in that hotbar slot goes to the inventory slot the minecart came from.
 */
public class TntRefill extends Module {
    private final Minecraft client = Minecraft.getInstance();

    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Integer> hotbarSlot = sg.add(new IntSetting.Builder()
        .name("hotbar-slot")
        .description("Hotbar slot (1-9) the TNT minecart should end up in.")
        .defaultValue(7)
        .range(1, 9)
        .sliderRange(1, 9)
        .build());

    private final Setting<Boolean> openInventory = sg.add(new BoolSetting.Builder()
        .name("open-inventory")
        .description("Show the inventory screen while swapping.")
        .defaultValue(true)
        .build());

    private final Setting<Integer> openTime = sg.add(new IntSetting.Builder()
        .name("open-time")
        .description("How long the inventory stays open after the swap, in ms.")
        .defaultValue(30)
        .range(0, 500)
        .sliderRange(0, 200)
        .visible(openInventory::get)
        .build());

    private boolean waitingToClose;
    private long openedAt;

    public TntRefill() {
        super(Categories.Combat, "tnt-cart-refill", "Swaps a TNT minecart from the inventory into a hotbar slot with one key press.");
    }

    @Override
    public void onActivate() {
        waitingToClose = false;
        if (client.player == null) {
            toggle();
            return;
        }

        int slot = hotbarSlot.get() - 1;
        if (isCart(client.player.getInventory().getItem(slot))) {
            info("Hotbar slot " + (slot + 1) + " already has TNT minecarts.");
            toggle();
            return;
        }

        // Pick the biggest stack of TNT minecarts in the main inventory.
        int best = -1, bestCount = 0;
        for (int i = 9; i <= 35; i++) {
            ItemStack s = client.player.getInventory().getItem(i);
            if (isCart(s) && s.getCount() > bestCount) {
                best = i;
                bestCount = s.getCount();
            }
        }
        if (best < 0) {
            warning("No TNT minecart in the inventory.");
            toggle();
            return;
        }

        if (openInventory.get()) client.setScreen(new InventoryScreen(client.player));
        InvUtils.quickSwap().fromId(slot).to(best);

        if (!openInventory.get() || openTime.get() <= 0) {
            closeInventory();
            toggle();
            return;
        }
        waitingToClose = true;
        openedAt = System.currentTimeMillis();
    }

    @Override
    public void onDeactivate() {
        waitingToClose = false;
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (!waitingToClose) return;
        if (System.currentTimeMillis() - openedAt >= openTime.get()) {
            waitingToClose = false;
            closeInventory();
            toggle();
        }
    }

    private void closeInventory() {
        if (client.player != null && client.screen instanceof InventoryScreen) client.player.closeContainer();
    }

    private boolean isCart(ItemStack s) {
        return s.is(Items.TNT_MINECART);
    }
}
