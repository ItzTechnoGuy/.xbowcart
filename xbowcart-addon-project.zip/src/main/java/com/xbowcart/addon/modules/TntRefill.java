package com.xbowcart.addon.modules;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.List;

/**
 * TNT Cart Refill by ItzTechnoGuy: one key press opens the inventory, waits a moment, swaps a TNT
 * minecart into the hotbar slot with the hotbar-number swap (not shift-click), checks that the swap
 * really happened (retries if the server undid it) and closes the inventory again.
 */
public class TntRefill extends Module {
    private final Minecraft client = Minecraft.getInstance();
    private final InvSession session = new InvSession();
    private boolean running;

    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Integer> hotbarSlot = sg.add(new IntSetting.Builder()
        .name("hotbar-slot")
        .description("Hotbar slot (1-9) the TNT minecart should end up in.")
        .defaultValue(7)
        .range(1, 9)
        .sliderRange(1, 9)
        .build());

    private final Setting<Boolean> useFixedSlot = sg.add(new BoolSetting.Builder()
        .name("use-fixed-slot")
        .description("On: always use the slot above. Off: use the hotbar slot the previous TNT minecart came from (falls back to the slot above).")
        .defaultValue(true)
        .build());

    private final Setting<Boolean> openInventory = sg.add(new BoolSetting.Builder()
        .name("open-inventory")
        .description("Show the inventory screen while swapping.")
        .defaultValue(true)
        .build());

    private final Setting<Integer> waitBeforeClick = sg.add(new IntSetting.Builder()
        .name("wait-before-click")
        .description("Time between opening the inventory and the swap, in ms (never in the same frame).")
        .defaultValue(40)
        .range(0, 500)
        .sliderRange(0, 200)
        .build());

    private final Setting<Boolean> waitUntilStill = sg.add(new BoolSetting.Builder()
        .name("wait-until-still")
        .description("Wait (up to 1.5 s) until you have stopped moving before swapping.")
        .defaultValue(false)
        .build());

    private final Setting<Integer> verifyWait = sg.add(new IntSetting.Builder()
        .name("verify-wait")
        .description("How long to wait after the swap before checking it worked (the swap is redone up to 2 times if it did not), in ms.")
        .defaultValue(80)
        .range(20, 500)
        .sliderRange(20, 300)
        .build());

    public TntRefill() {
        super(Categories.Combat, "tnt-cart-refill", "Swaps a TNT minecart from the inventory into a hotbar slot with one key press. By ItzTechnoGuy.");
    }

    @Override
    public void onActivate() {
        running = false;
        if (client.player == null) {
            toggle();
            return;
        }

        int previous = XBowCart.lastCartSlot;
        int slot = (useFixedSlot.get() || previous < 0) ? hotbarSlot.get() - 1 : previous;

        ItemStack inSlot = client.player.getInventory().getItem(slot);
        if (inSlot.is(Items.TNT_MINECART)) {
            info("Hotbar slot " + (slot + 1) + " already has TNT minecarts.");
            toggle();
            return;
        }

        // Biggest stack of TNT minecarts in the main inventory.
        int best = -1, bestCount = 0;
        for (int i = 9; i <= 35; i++) {
            ItemStack s = client.player.getInventory().getItem(i);
            if (s.is(Items.TNT_MINECART) && s.getCount() > bestCount) {
                best = i;
                bestCount = s.getCount();
            }
        }
        if (best < 0) {
            warning("No TNT minecart in the inventory.");
            toggle();
            return;
        }

        session.openScreen = openInventory.get();
        session.waitBeforeClick = waitBeforeClick.get();
        session.clickDelay = 0;
        session.verifyWait = verifyWait.get();
        session.waitUntilStill = waitUntilStill.get();
        session.start(List.of(new InvSession.Op(slot, best, Items.TNT_MINECART, inSlot.getItem())), System.currentTimeMillis());
        running = true;
    }

    @Override
    public void onDeactivate() {
        session.abort();
        running = false;
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (!running) return;
        if (session.tick(System.currentTimeMillis())) {
            running = false;
            if (session.failed > 0) warning("The server did not accept the swap.");
            toggle();
        }
    }
}
