# X-Bow Cart Addon 1.3 by ItzTechnoGuy (Meteor, Minecraft 1.21.11)

Modules (Meteor GUI -> Combat):
- X-Bow Cart (default key B)
- TNT Cart Refill (bind your own key)

Upload this zip to the GitHub repo (`xbowcart-addon-project.zip`); the build runs automatically.
Put the resulting `xbowcart-addon-1.3.0.jar` in the `mods` folder next to Meteor (remove older versions).
