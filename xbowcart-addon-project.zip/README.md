# X-Bow Cart Addon (Meteor, Minecraft 1.21.11)

Build the jar with GitHub Actions (works from a phone browser) - see the steps in the chat.
Put the resulting `xbowcart-addon-1.0.0.jar` in the `mods` folder next to Meteor.
In game: Meteor GUI -> Combat -> X-Bow Cart. Default key: B (you can rebind it).
