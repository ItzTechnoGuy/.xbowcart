# X-Bow Cart Addon 1.1 (Meteor, Minecraft 1.21.11)

Upload this zip to the GitHub repo (same file name `xbowcart-addon-project.zip`) and the build runs automatically.
Put the resulting `xbowcart-addon-1.1.0.jar` in the `mods` folder next to Meteor (remove the old 1.0.0 jar).
In game: Meteor GUI -> Combat -> X-Bow Cart. Default key: B.
