# X-Bow Cart Addon 2.0 by ItzTechnoGuy (Meteor, Minecraft 1.21.11)

Modules (Meteor GUI -> Combat):
- X-Bow Cart (default key B), with TNT minecart refill, placement circle and its own refill key
- Silent Totem

Upload this zip to the GitHub repo (`xbowcart-addon-project.zip`); the build runs automatically.
Put the resulting `xbowcart-addon-2.0.0.jar` in the `mods` folder next to Meteor (remove older versions).
